﻿#include "dbfile.h"
#include <QDebug>
#include <QDir>

QString p_id;
QString p_name;
QString p_mobile;
QString p_address;
QString lastInsertRowId;
int dbflag = 0;

dbFile::dbFile(QObject *parent) : QObject(parent)
{
    //==================DB Connection ========================

    if(!dbflag){   //will run once
        const QString DRIVER("QSQLITE");

        if(QSqlDatabase::isDriverAvailable(DRIVER)){
            qDebug()<<DRIVER<<" available";
        }else
            qDebug()<<DRIVER<<" not available";

        db = QSqlDatabase::addDatabase(DRIVER);

        qDebug()<<QDir::currentPath();

        //============= create db path ===================
        QString dbDir = "mkdir "+ QDir::currentPath() +"/db/";
        QString dbPath = QDir::currentPath() +"/db/mydatabase.db";
        //qDebug()<<"dbPath  : "<<dbPath;
        QFile file(dbPath);

        if(!file.exists()){
            int sysret = system(dbDir.toStdString().c_str());
            qDebug()<<"sysret  : "<<sysret;

            if(sysret !=0)
            {
                qDebug("DB Path Create error....");
            }
            qDebug("DB Path Created....");
        }else
            qDebug("DB Path Exist !");
        //===========================================

        db.setDatabaseName( QDir::currentPath() +"/db/mydatabase.db"); //your db in projetc directory,
        //uncheck shadow build in projects
        if(!db.open())
            qWarning() << "ERROR: " << db.lastError();
        else
            qDebug()<<" db open success";

        dbflag = 1;
    }
    //===================================================================================

    //QSqlQuery query1("DROP TABLE people");
    QSqlQuery query("CREATE TABLE IF NOT EXISTS people (id INTEGER PRIMARY KEY, name TEXT, mobile TEXT)");

    if(!query.isActive())
        qWarning() << "ERROR: " << query.lastError().text();

    query.clear();

    mread();

    //========================================================
}

void dbFile::minsert(QString name,QString mob)
{
    qDebug() <<"==> C++ : "<<name <<" : "<<mob;

    QSqlQuery query;

    query.prepare("SELECT id FROM people WHERE id = (SELECT MAX(id) FROM people);");

    if(!query.exec())
        qWarning() << "ERROR: " << query.lastError().text();

    while(query.next())
    {
        lastInsertRowId = query.value(0).toString();
        qDebug()<<"lastInsertRowId ===============================> "<<lastInsertRowId;

    }
    query.clear();
    //-------------------------------------------------
    int row_id = lastInsertRowId.toInt();
    row_id++;
    lastInsertRowId = QString::number(row_id);
    //--------------------------------------------------
    //============ db insert record ==================
    qDebug()<<"db inertion =========================> ";

    qDebug()<<"INSERT INTO people(id,name,mobile) VALUES('"+lastInsertRowId+"','"+name+"','"+mob+"'"+")";

    if(!query.exec("INSERT INTO people(id,name,mobile) VALUES('"+lastInsertRowId+"','"+name+"','"+mob+"'"+")"))
        qWarning() << "ERROR: " << query.lastError().text();
    //===============================================
}

void dbFile::mread()
{
    qDebug()<<"mread called.......";

    mid.clear();
    mname.clear();
    mmobile.clear();

    QSqlQuery query;
    query.prepare("SELECT id, name, mobile FROM people Order by id DESC;");
    if(!query.exec())
        qWarning() << "ERROR: " << query.lastError().text();

    while(query.next())
    {
        p_id = query.value(0).toString();
        p_name = query.value(1).toString();
        p_mobile = query.value(2).toString();

        qDebug()<<"======================================";
        qDebug()<<"p_id : "<<p_id;
        qDebug()<<"p_name : "<<p_name;
        qDebug()<<"p_mobile : "<<p_mobile;
        qDebug()<<"======================================";

        msetId(p_id);
        msetName(p_name);
        msetMobile(p_mobile);
    }
}

void dbFile::mupdate(QString id, QString m_name,QString m_mobile)
{
    //============ db update record ==================
    qDebug()<<"db Update =========================> ";

    qDebug()<<"UPDATE people SET name ='"+m_name+"',mobile ="+m_mobile+" WHERE id ="+id;

    QSqlQuery query;
    if(!query.exec("UPDATE people SET name ='"+ m_name+"',mobile ="+m_mobile+" WHERE id ="+id))
        qWarning() << "ERROR: " << query.lastError().text();
    //===============================================

}

void dbFile::mdelete(int id)
{
    //============ db delete record ==================
    qDebug()<<"db delete record =========================> ";

    qDebug()<<"DELETE FROM people WHERE id = "+QString::number(id);

    QSqlQuery query;
    if(!query.exec("DELETE FROM people WHERE id = "+QString::number(id)))
        qWarning() << "ERROR: " << query.lastError().text();
    //===============================================
}

QStringList dbFile::mgetId()
{
    return mid;
}

void dbFile::msetId(QString id)
{
    mid<<id;
    setUpdateid(mid);
}

QStringList dbFile::mgetName()
{
    return mname;
}

void dbFile::msetName(QString name)
{
    mname <<name;

    setUpdatename(mname);
}

QStringList dbFile::mgetMobile()
{
    return mmobile;
}

void dbFile::msetMobile(QString mob)
{
    mmobile <<mob;
    setUpdatemob(mmobile);
}


QStringList dbFile::updateid() const
{
    return m_updateid;
}

QStringList dbFile::updatename() const
{
    return m_updatename;
}

QStringList dbFile::updatemob() const
{
    return m_updatemob;
}

void dbFile::setUpdateid(QStringList updateid)
{
    if (m_updateid == updateid)
        return;

    m_updateid = updateid;
    emit updateidChanged(m_updateid);
}

void dbFile::setUpdatename(QStringList updatename)
{
    if (m_updatename == updatename)
        return;

    m_updatename = updatename;
    emit updatenameChanged(m_updatename);
}

void dbFile::setUpdatemob(QStringList updatemob)
{
    if (m_updatemob == updatemob)
        return;

    m_updatemob = updatemob;
    emit updatemobChanged(m_updatemob);
}
