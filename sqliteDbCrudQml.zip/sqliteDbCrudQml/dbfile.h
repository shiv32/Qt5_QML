#ifndef DBFILE_H
#define DBFILE_H

#include <QObject>

//db header
#include <QSqlDatabase>
#include <QSqlDriver>
#include <QSqlError>
#include <QSqlQuery>

class dbFile : public QObject
{
    Q_OBJECT
public:
    explicit dbFile(QObject *parent = nullptr);

    Q_PROPERTY(QStringList updateid READ updateid WRITE setUpdateid NOTIFY updateidChanged)
    Q_PROPERTY(QStringList updatename READ updatename WRITE setUpdatename NOTIFY updatenameChanged)
    Q_PROPERTY(QStringList updatemob READ updatemob WRITE setUpdatemob NOTIFY updatemobChanged)

    Q_INVOKABLE void minsert(QString name,QString mob);
    Q_INVOKABLE void mread();
    Q_INVOKABLE void mupdate(QString id, QString name,QString mob);
    Q_INVOKABLE void mdelete(int id);

    Q_INVOKABLE QStringList mgetId();
    Q_INVOKABLE void msetId(QString id);
    Q_INVOKABLE QStringList mgetName();
    Q_INVOKABLE void msetName(QString name);
    Q_INVOKABLE QStringList mgetMobile();
    Q_INVOKABLE void msetMobile(QString mob);

    QStringList mid;
    QStringList mname;
    QStringList mmobile;

    QSqlDatabase db;

    QStringList updateid() const;
    QStringList updatename() const;
    QStringList updatemob() const;

    void setUpdateid(QStringList updateid);
    void setUpdatename(QStringList updatename);
    void setUpdatemob(QStringList updatemob);

signals:
    void updateidChanged(QStringList updateid);
    void updatenameChanged(QStringList updatename);
    void updatemobChanged(QStringList updatemob);

private:
    QStringList m_updateid;
    QStringList m_updatename;
    QStringList m_updatemob;
};

#endif // DBFILE_H
