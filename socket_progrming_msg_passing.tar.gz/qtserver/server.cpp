#include "server.h"

#include <QDebug>
#include <QHostAddress>
#include <QAbstractSocket>

server::server(QObject *parent) : QObject(parent)
{
    myserver.listen(QHostAddress("127.0.0.1"), 4243);
    connect(&myserver, SIGNAL(newConnection()), this, SLOT(onNewConnection()));
    qDebug()<<"   Server Started...";
}

void server::onNewConnection()
{
    QTcpSocket *clientSocket = myserver.nextPendingConnection();
    connect(clientSocket, SIGNAL(readyRead()), this, SLOT(onReadyRead()));
    connect(clientSocket, SIGNAL(stateChanged(QAbstractSocket::SocketState)), this, SLOT(onSocketStateChanged(QAbstractSocket::SocketState)));
    mysockets.push_back(clientSocket);
}

void server::onSocketStateChanged(QAbstractSocket::SocketState socketState)
{
    if (socketState == QAbstractSocket::UnconnectedState)
    {
        QTcpSocket* sender = static_cast<QTcpSocket*>(QObject::sender());
        mysockets.removeOne(sender);
    }
}

void server::onReadyRead()
{
    QTcpSocket* sender = static_cast<QTcpSocket*>(QObject::sender());

    quint8 noOfmsg, counter;
    QString mytempdata;

    ApplToQtReply.clear ();
    myInfoList.clear();

    ApplToQtReply.append(sender->readAll());

    mytempdata = ApplToQtReply;

    // qDebug()<<"mytempdata ==> "<<mytempdata;

    noOfmsg = mytempdata.count(EOM_SP , Qt::CaseSensitive);
    //qDebug()<<"noOfmsg ==> "<<noOfmsg;

    //removing the end tag
    myInfoList = mytempdata.split(EOM_SP ,Qt::KeepEmptyParts, Qt::CaseSensitive);

    //qDebug()<<"myInfoList ==>"<<myInfoList;

    counter=noOfmsg;

    int result = 0;
    QStringList data;

    QString reply;
    while(counter)
    {
        //remove the empty tag in last
        myrequest.mypayload = myInfoList.at(noOfmsg - counter);
        counter--;
        // qDebug()<<"myrequest.payload ==>"<<myrequest.mypayload;
        QString payload = myrequest.mypayload;
        bool ok;
        qint8 index = payload.indexOf(MSG_SP);
        QString msgHeader = payload.left(index);
        mymsgid = msgHeader.toInt(&ok, 10);
        // qDebug()<<"from server mymsgid=================>" << mymsgid;
        qint32 chop = ( payload.length() ) - index -1;
        mydata = payload.right(chop);
        //qDebug()<<"from server mydata=================>" << mydata;
        //=========================
        data << mydata;
    }


    switch(mymsgid)
    {
    case SUM:
        result = data[0].toInt() + data[1].toInt();
        qDebug()<<"SUM : "<<result;
        reply = QString::number(server::SUM)+QChar(MSG_SP)+QString::number(result)+ QChar(EOM_SP);
        break;
    case SUBTRACT:
        result = data[0].toInt() - data[1].toInt();
        qDebug()<<"SUBTRACT : "<<result;
        reply = QString::number(server::SUBTRACT)+QChar(MSG_SP)+QString::number(result)+ QChar(EOM_SP);
        break;
    case DIVISION:
        if(data[1].toInt() != 0){
            result = (data[0].toInt() / data[1].toInt());
            qDebug()<<"DIVISION : "<<result;
            reply = QString::number(server::DIVISION)+QChar(MSG_SP)+QString::number(result)+ QChar(EOM_SP);
        }else{
            qDebug()<<"DIVISION : "<<"Not Defined";
            reply = QString::number(server::DIVISION)+QChar(MSG_SP)+QString("ND")+ QChar(EOM_SP); //ND -> not defined
        }
        break;
    case MULTIPLICATION:
        result = data[0].toInt() * data[1].toInt();
        qDebug()<<"MULTIPLICATION : "<<result;
        reply = QString::number(server::MULTIPLICATION)+QChar(MSG_SP)+QString::number(result)+ QChar(EOM_SP);
        break;
    default:
        break;
    }

    QByteArray datas2 = QByteArray::fromStdString(reply.toStdString());
    //qDebug()<<"datas2 ==> "<<datas2;
    sender->write(datas2);
}

