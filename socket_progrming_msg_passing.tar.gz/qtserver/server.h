#ifndef SERVER_H
#define SERVER_H

#include <QObject>
#include <QTcpServer>
#include <QTcpSocket>
#include <QByteArray>

#define MSG_SP  0x04
#define EOM_SP  0x03

class server : public QObject
{
    Q_OBJECT
public:
    explicit server(QObject *parent = nullptr);

     typedef struct
     {
         QString  mypayload;
     } MY_INFO_t;

    typedef enum
    {
    SUM = 0x0001,
    SUBTRACT,
    DIVISION,
    MULTIPLICATION
    }my_calculaor_enum;

public slots:
    void onNewConnection();
    void onSocketStateChanged(QAbstractSocket::SocketState socketState);
    void onReadyRead();

protected:
    MY_INFO_t myrequest;
    QByteArray ApplToQtReply;
    QStringList myInfoList;

private:
    QTcpServer  myserver;
    QList<QTcpSocket*>  mysockets;
    QString mydata;
    qint32 mymsgid;
};

#endif // SERVER_H
