#include "mysocket.h"
#include <QDebug>
#include <QHostAddress>
#include "unistd.h"

mySocket::mySocket(QObject *parent) : QObject(parent),mysocket(this)
{
    qDebug()<<"my socket called....";

    mytimer = new QTimer(this);
    mysocket.connectToHost(QHostAddress("127.0.0.1"), 4243);
    connect(&mysocket, SIGNAL(readyRead()), this, SLOT(onReadyRead()));
    connect(&mysocket, SIGNAL(stateChanged(QAbstractSocket::SocketState)), this, SLOT(onSocketStateChanged(QAbstractSocket::SocketState)));

}

void mySocket::sendDatatoServer(int en)
{
   // qDebug()<<"num1: "<<num1();
   // qDebug()<<"num2: "<<num2();

    QString req;

    switch(en)
    {
    case mySocket::SUM:
       req = QString::number(mySocket::SUM)+QChar(MSG_SP)+QString::number(num1())+QChar(EOM_SP)+QString::number(mySocket::SUM)+QChar(MSG_SP)+QString::number(num2())+QChar(EOM_SP);
        break;
    case mySocket::SUBTRACT:
       req = QString::number(mySocket::SUBTRACT)+QChar(MSG_SP)+QString::number(num1())+QChar(EOM_SP)+QString::number(mySocket::SUBTRACT)+QChar(MSG_SP)+QString::number(num2())+QChar(EOM_SP);
        break;
    case mySocket::DIVISION:
        req = QString::number(mySocket::DIVISION)+QChar(MSG_SP)+QString::number(num1())+QChar(EOM_SP)+QString::number(mySocket::DIVISION)+QChar(MSG_SP)+QString::number(num2())+QChar(EOM_SP);
        break;
    case mySocket::MULTIPLICATION:
       req= QString::number(mySocket::MULTIPLICATION)+QChar(MSG_SP)+QString::number(num1())+QChar(EOM_SP)+QString::number(mySocket::MULTIPLICATION)+QChar(MSG_SP)+QString::number(num2())+QChar(EOM_SP);
        break;
    default:
        break;
    }

    QByteArray datas2 = QByteArray::fromStdString(req.toStdString());
    mysocket.write(datas2);
}

int mySocket::num1() const
{
    return m_num1;
}

int mySocket::num2() const
{
    return m_num2;
}

void mySocket::setNum1(int num1)
{
    if (m_num1 == num1)
        return;

    m_num1 = num1;
    emit num1Changed(m_num1);
}

void mySocket::setNum2(int num2)
{
    if (m_num2 == num2)
        return;

    m_num2 = num2;
    emit num2Changed(m_num2);
}


QString mySocket::mydata() const
{
    return m_mydata;
}

qint32 mySocket::mymsgid() const
{
    return m_mymsgid;
}


void mySocket::onReadyRead()
{
    quint8 noOfmsg, cntFlag;
    QString mytempData;

    ApplToQtReply.clear ();
    myInfoList.clear();

    ApplToQtReply.append (mysocket.readAll());

    mytempData = ApplToQtReply;

    noOfmsg = mytempData.count(EOM_SP , Qt::CaseSensitive);
    qDebug()<<"noOfmsg ==> "<<noOfmsg;

    //removing the end tag
    myInfoList = mytempData.split(EOM_SP ,Qt::KeepEmptyParts, Qt::CaseSensitive);

    qDebug()<<"myInfoList ==>"<<myInfoList;

    cntFlag=noOfmsg;

    while(cntFlag)
    {
        myrequest.mypayload = myInfoList.at(noOfmsg - cntFlag);
        cntFlag--;

    }

    QString payload = myrequest.mypayload;
    bool ok;
    qint8 index = payload.indexOf(MSG_SP);
    QString msgHeader = payload.left(index);
    m_mymsgid = msgHeader.toInt(&ok, 10);
    //qDebug()<<"m_mymsgid ========> " << m_mymsgid;
    qint32 chop = ( payload.length() ) - index -1;
    m_mydata = payload.right(chop);
    //qDebug()<<"m_mydata =======> " << m_mydata;
    emit mySigDataReceived();
}

void mySocket::onSocketStateChanged(QAbstractSocket::SocketState socketState)
{
    if (socketState == QAbstractSocket::UnconnectedState)
    {
        setMydata("Server Down");
        connect(mytimer,SIGNAL(timeout()),this,SLOT(tryagain()));
        mytimer->start(1000);
    }

    if(socketState == QAbstractSocket::ConnectedState)
    {
        qDebug()<<"connected to server.";
        setMydata("Server Active");
        emit mySigDataReceived(); //as connected emit it
        mytimer->stop();
    }
}

void mySocket::tryagain()
{
    qDebug()<<"trying to connect server ...";
    mysocket.connectToHost(QHostAddress("127.0.0.1"), 4243);
    emit mySigDataReceived();
}

void mySocket::setMydata(QString mydata)
{
    m_mydata = mydata;
}

