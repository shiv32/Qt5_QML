#ifndef MYSOCKET_H
#define MYSOCKET_H

#include <QObject>
#include <QTcpSocket>
#include <QTimer>
#include <QQmlApplicationEngine>
#include <QByteArray>
#include <QStringList>

#define MSG_SP  0x04
#define EOM_SP  0x03

class mySocket : public QObject
{
    Q_OBJECT

public:
    explicit mySocket(QObject *parent = nullptr);

    QTimer *mytimer;

    Q_PROPERTY(int num1 READ num1 WRITE setNum1 NOTIFY num1Changed)
    Q_PROPERTY(int num2 READ num2 WRITE setNum2 NOTIFY num2Changed)
    Q_PROPERTY(QString mydata READ mydata WRITE setMydata);
    Q_PROPERTY(qint32 mymsgid READ mymsgid);

    Q_INVOKABLE void sendDatatoServer(int en);

    int num1() const;
    int num2() const;
    void setNum1(int num1);
    void setNum2(int num2);
    QString mydata() const;
    qint32 mymsgid() const;

    typedef struct
    {
        QString mypayload;
    }MY_INFO_t;

    Q_ENUMS (my_calculaor_enum); //to use in qml also

    typedef enum
    {
    SUM = 0x0001,
    SUBTRACT,
    DIVISION,
    MULTIPLICATION
    }my_calculaor_enum;

public slots:
    void onReadyRead();
    void onSocketStateChanged(QAbstractSocket::SocketState socketState);
    void tryagain();
    void setMydata(QString mydata);

signals:
    void num1Changed(int num1);
    void num2Changed(int num2);
    void mySigDataReceived ();

protected:
    MY_INFO_t myrequest;
    QByteArray  ApplToQtReply;
    QStringList myInfoList;

private:
    int m_num1;
    int m_num2;
    QTcpSocket  mysocket;
    mySocket *socketComm;
    QString m_mydata;
    qint32 m_mymsgid;
};

#endif // MYSOCKET_H
