#include "vegfruitmodel.h"

#include "vegfruitlist.h"
#include <QDebug>

VegFruitModel::VegFruitModel(QObject *parent)
    : QAbstractListModel(parent)
    , mList(nullptr)
{
}

int VegFruitModel::rowCount(const QModelIndex &parent) const
{
    // For list models only the root node (an invalid parent) should return the list's size. For all
    // other (valid) parents, rowCount() should return 0 so that it does not become a tree model.
    if (parent.isValid() || !mList)
        return 0;

    return mList->items().size();
}

QVariant VegFruitModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid() || !mList)
        return QVariant();

    //qDebug()<<"index row c++ ===============> "<<index.row();

    const VegFruitItem item = mList->items().at(index.row());
    switch (role) {
    case ItemNameRole:
        return QVariant(item.itemName);
    case UnitRole:
        return QVariant(item.unit);
    case BagsRole:
        return QVariant(item.bags);
    case PriceRole:
        return QVariant(item.price);
    case SumRole:
        return QVariant(item.sum);
    case CurntIndexRole:
        return QVariant(item.curntIndex);
    }
    return QVariant();
}

bool VegFruitModel::setData(const QModelIndex &index, const QVariant &value, int role)
{
    if (!mList)
        return false;

    VegFruitItem item = mList->items().at(index.row());
    switch (role) {
    case ItemNameRole:
        item.itemName = value.toString();
        break;
    case UnitRole:
        item.unit = value.toString();
        break;
    case BagsRole:
        item.bags = value.toString();
        break;
    case PriceRole:
        item.price = value.toString();
        break;
    case SumRole:
        item.sum = value.toString();
        break;
    case CurntIndexRole:
         item.curntIndex = value.toInt();
        break;
    }

    if (mList->setItemAt(index.row(), item)) {
        emit dataChanged(index, index, QVector<int>() << role);
        return true;
    }
    return false;

}

Qt::ItemFlags VegFruitModel::flags(const QModelIndex &index) const
{
    if (!index.isValid())
        return Qt::NoItemFlags;

    return Qt::ItemIsEditable;
}


QHash<int, QByteArray> VegFruitModel::roleNames() const
{
    QHash<int, QByteArray> names;

    names[ItemNameRole] = "itemName";
    names[UnitRole] = "unit";
    names[BagsRole] = "bags";
    names[PriceRole] = "price";
    names[SumRole] = "sum";
    names[CurntIndexRole] = "curntIndex";

    return names;
}

VegFruitList *VegFruitModel::list() const
{
    return mList;
}

void VegFruitModel::setList(VegFruitList *list)
{
    beginResetModel();

    if (mList)
        mList->disconnect(this);

    mList = list;

    if (mList) {
        connect(mList, &VegFruitList::preItemAppended, this, [=]() {
            const int index = mList->items().size();
            beginInsertRows(QModelIndex(), index, index);
        });
        connect(mList, &VegFruitList::postItemAppended, this, [=]() {
            endInsertRows();
        });

        connect(mList, &VegFruitList::preItemRemoved, this, [=](int index) {
            beginRemoveRows(QModelIndex(), index, index);
        });
        connect(mList, &VegFruitList::postItemRemoved, this, [=]() {
            endRemoveRows();
        });

        connect(mList, &VegFruitList::preItemReplaced, this, [=]() {
              beginResetModel();
        });
        connect(mList, &VegFruitList::postItemReplaced, this, [=]() {
              endResetModel();
        });
    }
    endResetModel();
}
