//ref: https://stackoverflow.com/questions/14209585/how-to-set-custom-offline-storage-path-from-javascript-in-qtquick

#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QDebug>
#include <QQmlEngine>
#include <QDir>
#include <QFile>
#include <QCryptographicHash>

//db header
#include <QSqlDatabase>
#include <QSqlDriver>
#include <QSqlError>
#include <QSqlQuery>

int main(int argc, char *argv[])
{
#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
#endif

    QGuiApplication app(argc, argv);

    QQmlApplicationEngine engine;

    //========================== Optional db from c++ ========================================

//    //-------------------------------
//    QSqlDatabase db;
//    const QString DRIVER("QSQLITE");

//    if(QSqlDatabase::isDriverAvailable(DRIVER)){
//        qDebug()<<DRIVER<<" available";
//    }else
//        qDebug()<<DRIVER<<" not available";

//    db = QSqlDatabase::addDatabase(DRIVER);

//    qDebug()<<QDir::currentPath();

//    //============= create db path ===================
//    QString dbDir = "mkdir "+ QDir::currentPath() +"/db/";
//    QString dbPath = QDir::currentPath() +"/db/CrazyBox.sqlite";
//    //qDebug()<<"dbPath  : "<<dbPath;
//    QFile file(dbPath);

//    if(!file.exists()){
//       int sysret = system(dbDir.toStdString().c_str());
//       qDebug()<<"sysret  : "<<sysret;

//       if(sysret !=0)
//       {
//         qDebug("DB Path Create error....");
//       }
//         qDebug("DB Path Created....");
//    }else
//         qDebug("DB Path Exist !");
//    //===========================================

//    db.setDatabaseName( QDir::currentPath() +"/db/CrazyBox.sqlite"); //your db in projetc directory,
//                                                                   //uncheck shadow build in projects
//    if(!db.open())
//        qWarning() << "ERROR: " << db.lastError();
//    else
//        qDebug()<<" db open success";

//   //-----------------------------------------
//     QQmlEngine qqEngine; //Creates an engine to fetch the OfflineStoragePath
//     const QString dataFolder = qqEngine.offlineStoragePath();
//     //Sets the Database folder
//     QDir dir(dataFolder+"/Databases");

//    if (!dir.exists()) {
//        dir.mkpath(".");
//    }

//    //Encrypt the database name with MD5, default from Qt
//    QString new_name = QString(QCryptographicHash::hash(("CrazyBox"),QCryptographicHash::Md5).toHex());

//    //Pick the source DB to be copied to the new location with the MD5 name
//    QFile file2(dbPath);
//    QFile dbFilePath(dataFolder+"/Databases/" + new_name + ".sqlite");
//    bool ret;

//    if(!dbFilePath.exists())
//    {
//        ret = file2.copy(dataFolder+"/Databases/" + new_name + ".sqlite");

//        if(!ret)
//        {
//            qDebug("DB file error");
//        }
//        else
//        {
//            qDebug("DB file success");
//        }

//    }else
//        qDebug("DB file Exist");


//    file.close();
//    dbFilePath.close();

//    //The Sqslite must have a ini file with the database version and metadata in the same folder,
//    //so we also copy this file
//    QFile fileIni(QDir::currentPath() +"/db/CrazyBox.ini");
//    QFile dbIniPath(dataFolder+"/Databases/" + new_name + ".ini");

//    if(!dbIniPath.exists())
//    {
//        ret = fileIni.copy(dataFolder+"/Databases/" + new_name + ".ini");

//        if(!ret)
//        {
//            qDebug("DB file ini error");
//        }
//        else
//        {
//            qDebug("DB file ini success");
//        }

//    }else
//         qDebug("DB iniFile Exist");

//    fileIni.close();
//    dbIniPath.close();

//    QString pathDetail = "ls "+dataFolder+"/Databases/";
//    qDebug()<<"DB path files : "+dataFolder+"/Databases/";
//    system(pathDetail.toStdString().c_str());
   //=======================================================================

    const QUrl url(QStringLiteral("qrc:/main.qml"));
    QObject::connect(&engine, &QQmlApplicationEngine::objectCreated,
                     &app, [url](QObject *obj, const QUrl &objUrl) {
        if (!obj && url == objUrl)
            QCoreApplication::exit(-1);
    }, Qt::QueuedConnection);
    engine.load(url);

    return app.exec();
}
