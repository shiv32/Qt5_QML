#include "addressbookmodel.h"
#include "addressbookdata.h"
#include <QDebug>

AddressBookData  AB;

AddressBookmodel::AddressBookmodel(QObject *parent)
    : QAbstractListModel(parent)
    ,mList(nullptr)
{
}


int AddressBookmodel::rowCount(const QModelIndex &parent) const
{
    // For list models only the root node (an invalid parent) should return the list's size. For all
    // other (valid) parents, rowCount() should return 0 so that it does not become a tree model.
    if (parent.isValid() || !mList)
        return 0;

    return mList->items().size();
}

QVariant AddressBookmodel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid() || !mList)
        return QVariant();

    //===
    const int myrow = index.row();
    //qDebug()<<"c++ row ===============================+++++===> "<<myrow;
    AB.getMyRow(myrow);

    const AddressBookitem item = mList->items().at(index.row());

    switch (role) {
    case IdRole:
        return QVariant(item.Id);
    case NameRole:
        return QVariant(item.name);
    case MobilRole:
        return QVariant(item.mobile);
    case AddressRole:
        return QVariant(item.address);
    }

    return QVariant();
}

bool AddressBookmodel::setData(const QModelIndex &index, const QVariant &value, int role)
{
    if (!mList)
        return false;

    AddressBookitem item = mList->items().at(index.row());
    switch (role) {
    case IdRole:
        item.Id = value.toString();
             break;
    case NameRole:
        item.name = value.toString();
        break;
    case MobilRole:
        item.mobile = value.toString();
        break;
    case AddressRole:
        item.address = value.toString();
        break;
    }

    if (mList->setItemAt(index.row(), item)) {
        emit dataChanged(index, index, QVector<int>() << role);
        return true;
    }
    return false;
}

Qt::ItemFlags AddressBookmodel::flags(const QModelIndex &index) const
{
    if (!index.isValid())
        return Qt::NoItemFlags;

    return Qt::ItemIsEditable;
}

QHash<int, QByteArray> AddressBookmodel::roleNames() const
{
    QHash<int, QByteArray> names;
    names[IdRole] = "Id";
    names[NameRole] = "name";
    names[MobilRole] = "mobile";
    names[AddressRole] = "address";
    return names;
}

AddressBookData *AddressBookmodel::list() const
{
    return mList;
}

void AddressBookmodel::setList(AddressBookData *list)
{
    beginResetModel();

    if (mList)
        mList->disconnect(this);

    mList = list;

    if (mList) {
        connect(mList, &AddressBookData::preItemAppended, this, [=]() {
            const int index = mList->items().size();
            beginInsertRows(QModelIndex(), index, index);
        });
        connect(mList, &AddressBookData::postItemAppended, this, [=]() {
            endInsertRows();
        });

        connect(mList, &AddressBookData::preItemRemoved, this, [=](int index) {
            beginRemoveRows(QModelIndex(), index, index);
        });
        connect(mList, &AddressBookData::postItemRemoved, this, [=]() {
            endRemoveRows();
        });
    }
    endResetModel();
}

int AddressBookmodel::count() const
{
    //return m_count;
    return rowCount(QModelIndex());
}
