#ifndef ADDRESSBOOKDATA_H
#define ADDRESSBOOKDATA_H

#include <QObject>
#include <QVector>

//db header
#include <QSqlDatabase>
#include <QSqlDriver>
#include <QSqlError>
#include <QSqlQuery>

struct AddressBookitem
{
    QString Id;
    QString name;
    QString mobile;
    QString address;
};


class AddressBookData : public QObject
{
    Q_OBJECT
public:
    Q_PROPERTY(QString name READ name WRITE setName NOTIFY nameChanged)
    Q_PROPERTY(QString mobile READ mobile WRITE setMobile NOTIFY mobileChanged)
    Q_PROPERTY(QString address READ address WRITE setAddress NOTIFY addressChanged)

    explicit AddressBookData(QObject *parent = nullptr);

    QVector<AddressBookitem> items() const;
    bool setItemAt(int index, const AddressBookitem &item);

    void getMyRow(int);
    Q_INVOKABLE void getRowIdDb(int);
    Q_INVOKABLE void updateRow(int);

    QString name() const;
    QString mobile() const;
    QString address() const;
    QSqlDatabase db;

signals:
    void preItemAppended();
    void postItemAppended();

    void preItemReplaced();
    void postItemReplaced();

    void preItemRemoved(int index);
    void postItemRemoved();

    void nameChanged(QString name);
    void mobileChanged(QString mobile);
    void addressChanged(QString address);

public slots:
    void appendItem(QString,QString,QString,QString);
    void removeItems();
    void getItem();

    void setName(QString name);
    void setMobile(QString mobile);
    void setAddress(QString address);

private:
    QVector<AddressBookitem> mItems;

    QString m_name;
    QString m_mobile;
    QString m_address;
};

#endif // ADDRESSBOOKDATA_H
