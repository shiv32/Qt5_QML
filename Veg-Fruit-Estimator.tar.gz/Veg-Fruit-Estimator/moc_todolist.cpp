/****************************************************************************
** Meta object code from reading C++ file 'todolist.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.13.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "todolist.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'todolist.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.13.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_ToDoList_t {
    QByteArrayData data[21];
    char stringdata0[234];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_ToDoList_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_ToDoList_t qt_meta_stringdata_ToDoList = {
    {
QT_MOC_LITERAL(0, 0, 8), // "ToDoList"
QT_MOC_LITERAL(1, 9, 15), // "preItemAppended"
QT_MOC_LITERAL(2, 25, 0), // ""
QT_MOC_LITERAL(3, 26, 16), // "postItemAppended"
QT_MOC_LITERAL(4, 43, 14), // "preItemRemoved"
QT_MOC_LITERAL(5, 58, 5), // "index"
QT_MOC_LITERAL(6, 64, 15), // "postItemRemoved"
QT_MOC_LITERAL(7, 80, 15), // "preItemReplaced"
QT_MOC_LITERAL(8, 96, 16), // "postItemReplaced"
QT_MOC_LITERAL(9, 113, 12), // "comboChanged"
QT_MOC_LITERAL(10, 126, 5), // "combo"
QT_MOC_LITERAL(11, 132, 16), // "sumRowStrChanged"
QT_MOC_LITERAL(12, 149, 9), // "sumRowStr"
QT_MOC_LITERAL(13, 159, 11), // "tsumChanged"
QT_MOC_LITERAL(14, 171, 4), // "tsum"
QT_MOC_LITERAL(15, 176, 7), // "getItem"
QT_MOC_LITERAL(16, 184, 8), // "setCombo"
QT_MOC_LITERAL(17, 193, 12), // "setSumRowStr"
QT_MOC_LITERAL(18, 206, 7), // "setTsum"
QT_MOC_LITERAL(19, 214, 6), // "getRow"
QT_MOC_LITERAL(20, 221, 12) // "resetQmlData"

    },
    "ToDoList\0preItemAppended\0\0postItemAppended\0"
    "preItemRemoved\0index\0postItemRemoved\0"
    "preItemReplaced\0postItemReplaced\0"
    "comboChanged\0combo\0sumRowStrChanged\0"
    "sumRowStr\0tsumChanged\0tsum\0getItem\0"
    "setCombo\0setSumRowStr\0setTsum\0getRow\0"
    "resetQmlData"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_ToDoList[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      15,   14, // methods
       3,  120, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       9,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   89,    2, 0x06 /* Public */,
       3,    0,   90,    2, 0x06 /* Public */,
       4,    1,   91,    2, 0x06 /* Public */,
       6,    0,   94,    2, 0x06 /* Public */,
       7,    0,   95,    2, 0x06 /* Public */,
       8,    0,   96,    2, 0x06 /* Public */,
       9,    1,   97,    2, 0x06 /* Public */,
      11,    1,  100,    2, 0x06 /* Public */,
      13,    1,  103,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      15,    0,  106,    2, 0x0a /* Public */,
      16,    1,  107,    2, 0x0a /* Public */,
      17,    1,  110,    2, 0x0a /* Public */,
      18,    1,  113,    2, 0x0a /* Public */,

 // methods: name, argc, parameters, tag, flags
      19,    1,  116,    2, 0x02 /* Public */,
      20,    0,  119,    2, 0x02 /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   10,
    QMetaType::Void, QMetaType::QString,   12,
    QMetaType::Void, QMetaType::QString,   14,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   10,
    QMetaType::Void, QMetaType::QString,   12,
    QMetaType::Void, QMetaType::QString,   14,

 // methods: parameters
    QMetaType::QString, QMetaType::QString,    2,
    QMetaType::Void,

 // properties: name, type, flags
      10, QMetaType::QString, 0x00495103,
      12, QMetaType::QString, 0x00495103,
      14, QMetaType::QString, 0x00495103,

 // properties: notify_signal_id
       6,
       7,
       8,

       0        // eod
};

void ToDoList::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<ToDoList *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->preItemAppended(); break;
        case 1: _t->postItemAppended(); break;
        case 2: _t->preItemRemoved((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: _t->postItemRemoved(); break;
        case 4: _t->preItemReplaced(); break;
        case 5: _t->postItemReplaced(); break;
        case 6: _t->comboChanged((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 7: _t->sumRowStrChanged((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 8: _t->tsumChanged((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 9: _t->getItem(); break;
        case 10: _t->setCombo((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 11: _t->setSumRowStr((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 12: _t->setTsum((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 13: { QString _r = _t->getRow((*reinterpret_cast< QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 14: _t->resetQmlData(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (ToDoList::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&ToDoList::preItemAppended)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (ToDoList::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&ToDoList::postItemAppended)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (ToDoList::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&ToDoList::preItemRemoved)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (ToDoList::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&ToDoList::postItemRemoved)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (ToDoList::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&ToDoList::preItemReplaced)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (ToDoList::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&ToDoList::postItemReplaced)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (ToDoList::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&ToDoList::comboChanged)) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (ToDoList::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&ToDoList::sumRowStrChanged)) {
                *result = 7;
                return;
            }
        }
        {
            using _t = void (ToDoList::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&ToDoList::tsumChanged)) {
                *result = 8;
                return;
            }
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<ToDoList *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QString*>(_v) = _t->combo(); break;
        case 1: *reinterpret_cast< QString*>(_v) = _t->sumRowStr(); break;
        case 2: *reinterpret_cast< QString*>(_v) = _t->tsum(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        auto *_t = static_cast<ToDoList *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setCombo(*reinterpret_cast< QString*>(_v)); break;
        case 1: _t->setSumRowStr(*reinterpret_cast< QString*>(_v)); break;
        case 2: _t->setTsum(*reinterpret_cast< QString*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

QT_INIT_METAOBJECT const QMetaObject ToDoList::staticMetaObject = { {
    &QObject::staticMetaObject,
    qt_meta_stringdata_ToDoList.data,
    qt_meta_data_ToDoList,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *ToDoList::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ToDoList::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_ToDoList.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int ToDoList::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 15)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 15;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 15)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 15;
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 3;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 3;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 3;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 3;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 3;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 3;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void ToDoList::preItemAppended()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void ToDoList::postItemAppended()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void ToDoList::preItemRemoved(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void ToDoList::postItemRemoved()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void ToDoList::preItemReplaced()
{
    QMetaObject::activate(this, &staticMetaObject, 4, nullptr);
}

// SIGNAL 5
void ToDoList::postItemReplaced()
{
    QMetaObject::activate(this, &staticMetaObject, 5, nullptr);
}

// SIGNAL 6
void ToDoList::comboChanged(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void ToDoList::sumRowStrChanged(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}

// SIGNAL 8
void ToDoList::tsumChanged(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 8, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
