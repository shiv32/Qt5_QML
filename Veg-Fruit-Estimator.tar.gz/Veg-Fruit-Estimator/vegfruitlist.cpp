#include "vegfruitlist.h"
#include <QDebug>

//golabal variables
QString myRow;
int sum;
int totalSumm = 0;
QString my_unit;
QString my_bags;
QString my_price;


VegFruitList::VegFruitList(QObject *parent) : QObject(parent)
{

    mItems.append({QStringLiteral("Potato"),QStringLiteral(" "),QStringLiteral(" "),QStringLiteral(" "),QStringLiteral("0"),0});
    mItems.append({QStringLiteral("Tomato"),QStringLiteral(" "),QStringLiteral(" "),QStringLiteral(" "),QStringLiteral("0"),0});
    mItems.append({QStringLiteral("Apple"),QStringLiteral(" "),QStringLiteral(" "),QStringLiteral(" "),QStringLiteral("0"),0});
    mItems.append({QStringLiteral("Orange"),QStringLiteral(" "),QStringLiteral(" "),QStringLiteral(" "),QStringLiteral("0"),0});
}

QVector<VegFruitItem> VegFruitList::items() const
{
    return mItems;
}

bool VegFruitList::setItemAt(int index, const VegFruitItem &item)
{
    if (index < 0 || index >= mItems.size())
        return false;

    const VegFruitItem &oldItem = mItems.at(index);
    if (item.itemName == oldItem.itemName && item.unit == oldItem.unit && item.bags == oldItem.bags && item.price == oldItem.price && item.sum == oldItem.sum && item.curntIndex == oldItem.curntIndex)
        return false;

    mItems[index] = item;
    return true;
}

QString VegFruitList::getRow(QString m_row)
{
    //qDebug()<<"c++  combo data==> "<<combo();
    //qDebug()<<"c++ row : "<<m_row;
    myRow = m_row;

    mItems.replace(m_row.toInt(),
                   {
                       mItems.at(m_row.toInt()).itemName,
                       combo(),
                       mItems.at(m_row.toInt()).bags,
                       mItems.at(m_row.toInt()).price,
                       mItems.at(m_row.toInt()).sum,
                       mItems.at(m_row.toInt()).curntIndex
                   }
                   );

    return m_row;
}

void VegFruitList::resetQmlData()
{
    emit preItemReplaced() ;
    for(int i = 0; i < mItems.size();) {
        mItems.replace(i,
                       {
                           mItems.at(i).itemName,  //veg/fruit item
                           "10",    //unit
                           "",      //bags
                           "",      //price
                           "0",     //sum
                           0        //combo index
                       }
                       );
        i++;
    }
    emit postItemReplaced() ;
    setTsum("0");   //reset sum value
}

void VegFruitList::updateMyRow(int row)
{
    //update each row
    my_unit = my_unit.remove("Kg");
    sum = my_unit.toInt() * my_bags.toInt() * my_price.toInt();
    totalSumm += sum;
    setSumRowStr(QString::number(sum));

    emit preItemReplaced() ;

    mItems.replace(row,
                   {
                       mItems.at(row).itemName,
                       mItems.at(row).unit,
                       mItems.at(row).bags,
                       mItems.at(row).price,
                       m_sumRowStr,
                       mItems.at(row).curntIndex
                   }
                   );

    emit postItemReplaced() ;

    sum = 0;
    //qDebug()<<"=================> totalSumm : "<<totalSumm;
    setTsum(QString::number(totalSumm));
}


QString VegFruitList::combo() const
{
    // qDebug()<<"c++  combo data==> "<<m_combo;
    return m_combo;
}


QString VegFruitList::sumRowStr() const
{
    return m_sumRowStr;
}

QString VegFruitList::tsum() const
{
    return m_tsum;
}


void VegFruitList::getItem()
{
    QString m_itemname;
    //    QString m_unit;
    //    QString m_bags;
    //    QString m_price;
    QString m_sum;

    // qDebug()<<"mItems.size() "<<mItems.size();

    for(int i = 0; i < mItems.size();) {
        m_itemname = mItems.at(i).itemName;
        my_unit =  mItems.at(i).unit;
        my_bags = mItems.at(i).bags;
        my_price = mItems.at(i).price;
        m_sum = mItems.at(i).sum;

        //        qDebug()<<"my item : "<<m_itemname
        //                <<" my unit: "<<my_unit
        //                <<"bags: "<<my_bags
        //                <<"price: "<<my_price
        //         qDebug()<<"sum: "<<m_sum;

        updateMyRow(i);
        i++;
    }
    totalSumm = 0;
}

void VegFruitList::setCombo(QString combo)
{
    if (m_combo == combo)
        return;

    m_combo = combo;
    emit comboChanged(m_combo);
}

void VegFruitList::setSumRowStr(QString sumRowStr)
{
    if (m_sumRowStr == sumRowStr)
        return;

    m_sumRowStr = sumRowStr;
    emit sumRowStrChanged(m_sumRowStr);
}

void VegFruitList::setTsum(QString tsum)
{
    if (m_tsum == tsum)
        return;

    m_tsum = tsum;
    emit tsumChanged(m_tsum);
}
