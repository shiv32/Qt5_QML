#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <QStringListModel>

#include "vegfruitlist.h"
#include "vegfruitmodel.h"

int main(int argc, char *argv[])
{
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
    QGuiApplication app(argc, argv);

    //====
    qmlRegisterType<VegFruitModel>("VegFruit", 1, 0, "VegFruitModel");
    qmlRegisterUncreatableType<VegFruitList>("VegFruit", 1, 0, "VegFruitList",
                                         QStringLiteral("VegFruitList should not be created in QML"));
    //===
    VegFruitList vegFruitList;

    QQmlApplicationEngine engine;

    //====
    engine.rootContext()->setContextProperty(QStringLiteral("vegFruitList"), &vegFruitList);

//    //=====
//    QStringList dataList;
//    dataList.append("10 Kg");
//    dataList.append("20 Kg");
//    dataList.append("30 Kg");
//    dataList.append("40 Kg");
//    engine.rootContext()->setContextProperty("myModel",dataList);

    engine.load(QUrl(QLatin1String("qrc:/main.qml")));
    if (engine.rootObjects().isEmpty())
        return -1;

    return app.exec();
}
