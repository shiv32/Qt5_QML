#include "classobj.h"
#include <QDateTime>
#include <QDir>
#include <QQuickWindow>
#include <QDebug>

classObj::classObj(QObject *parent) : QObject(parent)
{

}

bool classObj::eventFilter(QObject *obj, QEvent *ev)
{
    QString dateInterval = QString::number(QDateTime::currentSecsSinceEpoch());

    //    QDir dir("screenshot");
    //    if(!dir.exists())
    //        dir.mkpath(".");

    QString path = QDir::currentPath()+"/screenshot/";
    QFile file(path+"conf.txt");

    if(!file.open(QIODevice::ReadOnly)) {

    }

    QTextStream in(&file);

    QString line = in.readLine();

    if(line == "yes")
    {
        qDebug()<<"File read : "<<line;

        //screenshot on mouse single click
//        if(ev->type() == QEvent::MouseButtonPress) {
//            QQuickWindow *window   = qobject_cast<QQuickWindow *>(root_object);
//            window->grabWindow().save(path+"Image_fromCPP_"+dateInterval+".png");
//        }

         //screenshot on mouse double click
        if(ev->type() == QEvent::MouseButtonDblClick) {
            QQuickWindow *window   = qobject_cast<QQuickWindow *>(root_object);
            window->grabWindow().save(path+"Image_fromCPP_"+dateInterval+".png");
        }

    }else
    {
        qDebug()<<"conf file not found";
    }

    file.close();
    return QObject::eventFilter(obj, ev);
}
