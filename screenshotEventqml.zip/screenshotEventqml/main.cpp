
/***************************************************************************************************************************
ref:https://stackoverflow.com/questions/21697185/how-to-take-screenshot-of-qml-application-without-qquickview
****************************************************************************************************************************/

#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include "classobj.h"

int main(int argc, char *argv[])
{
#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
#endif

    QGuiApplication app(argc, argv);

    QQmlApplicationEngine engine;



    const QUrl url(QStringLiteral("qrc:/main.qml"));
    QObject::connect(&engine, &QQmlApplicationEngine::objectCreated,
                     &app, [url](QObject *obj, const QUrl &objUrl) {
        if (!obj && url == objUrl)
            QCoreApplication::exit(-1);
    }, Qt::QueuedConnection);

    engine.load(url);

    //============ screenshot of qml UI from c++ side on event ======================
     classObj co;
     QObject *objekt = engine.rootObjects().first();
     co.root_object = objekt;
     app.installEventFilter(&co);
    //===============================================================================

    return app.exec();
}
