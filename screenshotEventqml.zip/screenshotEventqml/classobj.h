#ifndef CLASSOBJ_H
#define CLASSOBJ_H

#include <QObject>

class classObj : public QObject
{
    Q_OBJECT
public:
    explicit classObj(QObject *parent = nullptr);

    QObject *root_object = nullptr;
    bool eventFilter(QObject *obj, QEvent *ev);

signals:

};

#endif // CLASSOBJ_H
