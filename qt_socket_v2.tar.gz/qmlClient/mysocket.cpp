#include "mysocket.h"
#include <QDebug>
#include <QHostAddress>

mySocket::mySocket(QObject *parent) : QObject(parent),mysocket(this)
{
    qDebug()<<"my socket called....";
    mytimer = new QTimer(this);

    mysocket.connectToHost(QHostAddress("127.0.0.1"), 4243);
    connect(&mysocket, SIGNAL(readyRead()), this, SLOT(onReadyRead()));
    connect(&mysocket, SIGNAL(stateChanged(QAbstractSocket::SocketState)), this, SLOT(onSocketStateChanged(QAbstractSocket::SocketState)));
}

void mySocket::sendDatatoServer()
{
    qDebug()<<"num1: "<<num1();
    qDebug()<<"num2: "<<num2();

    QString request = QString::number(num1())+"+"+QString::number(num2());
    mysocket.write(QByteArray::fromStdString(request.toStdString()));
}

int mySocket::num1() const
{
    return m_num1;
}

int mySocket::num2() const
{
    return m_num2;
}

void mySocket::setNum1(int num1)
{
    if (m_num1 == num1)
        return;

    m_num1 = num1;
    emit num1Changed(m_num1);
}

void mySocket::setNum2(int num2)
{
    if (m_num2 == num2)
        return;

    m_num2 = num2;
    emit num2Changed(m_num2);
}

QString mySocket::reslt() const
{
    return m_reslt;
}

void mySocket::setReslt(QString reslt)
{
    if (m_reslt == reslt)
        return;

    m_reslt = reslt;
    emit resltChanged(m_reslt);
}

void mySocket::onReadyRead()
{
    QByteArray reslt = mysocket.readAll();
    qDebug() << reslt;
    setReslt(reslt);
}

void mySocket::onSocketStateChanged(QAbstractSocket::SocketState socketState)
{
    if (socketState == QAbstractSocket::UnconnectedState)
    {
       setReslt("Server Down");
       connect(mytimer,SIGNAL(timeout()),this,SLOT(tryagain()));
       mytimer->start(1000);
    }

    if(socketState == QAbstractSocket::ConnectedState)
    {
        qDebug()<<"connected to server.";
        setReslt("Server Active");
        mytimer->stop();
    }
}

void mySocket::tryagain()
{
    qDebug()<<"trying to connect server ...";
    mysocket.connectToHost(QHostAddress("127.0.0.1"), 4243);
}
