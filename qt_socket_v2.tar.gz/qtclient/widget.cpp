#include "widget.h"
#include "ui_widget.h"

#include <QDebug>
#include <QHostAddress>

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
    , mysocket(this)
{
    ui->setupUi(this);

    this->setWindowTitle("Qt Widget App Client");
    mytimer = new QTimer(this);

    mysocket.connectToHost(QHostAddress("127.0.0.1"), 4243);
    connect(&mysocket, SIGNAL(readyRead()), this, SLOT(onReadyRead()));
    connect(&mysocket, SIGNAL(stateChanged(QAbstractSocket::SocketState)), this, SLOT(onSocketStateChanged(QAbstractSocket::SocketState)));
}

Widget::~Widget()
{
    delete ui;
}

void Widget::onReadyRead()
{
        QByteArray reslt = mysocket.readAll();
        qDebug() << reslt;
        ui->le_result->setText(QString(reslt));
}


void Widget::on_pb_add_clicked()
{
    int num1 = ui->le_num1->text().toInt();
    int num2 = ui->le_num2->text().toInt();
    QString request = QString::number(num1)+"+"+QString::number(num2);
    mysocket.write(QByteArray::fromStdString(request.toStdString()));
}

void Widget::onSocketStateChanged(QAbstractSocket::SocketState socketState)
{
    if (socketState == QAbstractSocket::UnconnectedState)
    {
         ui->le_result->setText("Server Down");
         connect(mytimer,SIGNAL(timeout()),this,SLOT(tryagain()));
         mytimer->start(1000);
    }

    if(socketState == QAbstractSocket::ConnectedState)
    {
        qDebug()<<"connected to server.";
        ui->le_result->setText("Server Active");
        mytimer->stop();
    }
}

void Widget::tryagain()
{
    qDebug()<<"trying to connect server ...";
    mysocket.connectToHost(QHostAddress("127.0.0.1"), 4243);
}
