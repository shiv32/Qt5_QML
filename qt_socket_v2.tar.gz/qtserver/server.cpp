#include "server.h"

#include <QDebug>
#include <QHostAddress>
#include <QAbstractSocket>

server::server(QObject *parent) : QObject(parent)
{
    myserver.listen(QHostAddress("127.0.0.1"), 4243);
    connect(&myserver, SIGNAL(newConnection()), this, SLOT(onNewConnection()));
}


void server::onNewConnection()
{
    QTcpSocket *clientSocket = myserver.nextPendingConnection();
    connect(clientSocket, SIGNAL(readyRead()), this, SLOT(onReadyRead()));
    connect(clientSocket, SIGNAL(stateChanged(QAbstractSocket::SocketState)), this, SLOT(onSocketStateChanged(QAbstractSocket::SocketState)));

    mysockets.push_back(clientSocket);

//    for (QTcpSocket* socket : mysockets) {
////      socket->write(QByteArray::fromStdString(clientSocket->peerAddress().toString().toStdString() + " connected to server shiv !\n"));
//        socket->write(QByteArray("server active"));

//    }
}

void server::onSocketStateChanged(QAbstractSocket::SocketState socketState)
{
    if (socketState == QAbstractSocket::UnconnectedState)
    {
        QTcpSocket* sender = static_cast<QTcpSocket*>(QObject::sender());
        mysockets.removeOne(sender);
    }
}

void server::onReadyRead()
{
    QTcpSocket* sender = static_cast<QTcpSocket*>(QObject::sender());
    QByteArray datas = sender->readAll();
    //qDebug() << datas;
    QString clientReq = QString(datas);   //a+b
    //qDebug()<<clientReq;
    qDebug()<<clientReq.section('+', 0, 0); // a
    qDebug()<<clientReq.section('+',1);     // b

    int num1 = clientReq.section('+', 0, 0).toInt();  //  a
    int num2 = clientReq.section('+',1).toInt();      //b

    int reslt = num1 + num2; //a+b

    sender->write(QByteArray::fromStdString(QString::number(reslt).toStdString()));

    //data exchange b/t clients
    //    for (QTcpSocket* socket : _sockets) {
    //        if (socket != sender)
    //            socket->write(QByteArray::fromStdString(sender->peerAddress().toString().toStdString() + ": " + datas.toStdString()));
    //    }
}
