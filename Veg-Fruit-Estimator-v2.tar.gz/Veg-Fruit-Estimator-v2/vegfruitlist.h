#ifndef TODOLIST_H
#define TODOLIST_H

#include <QObject>
#include <QVector>

#include "vegfruitmodel.h"

struct VegFruitItem
{
    QString itemName;
    QString unit;
    QString bags;
    QString price;
    QString sum;
    int curntIndex;
};

class VegFruitList : public QObject
{
    Q_OBJECT
public:
    explicit VegFruitList(QObject *parent = nullptr);

    QVector<VegFruitItem> items() const;

    bool setItemAt(int index, const VegFruitItem &item);

    Q_PROPERTY(QString combo READ combo WRITE setCombo NOTIFY comboChanged)
    Q_PROPERTY(QString sumRowStr READ sumRowStr WRITE setSumRowStr NOTIFY sumRowStrChanged)

    Q_INVOKABLE QString getRow(QString);
    Q_INVOKABLE void resetQmlData();

    Q_PROPERTY(QString tsum READ tsum WRITE setTsum NOTIFY tsumChanged)

    void updateMyRow(int row);

    QString combo() const;
    QString sumRowStr() const;
    QString tsum() const;


signals:
    void preItemAppended();
    void postItemAppended();

    void preItemRemoved(int index);
    void postItemRemoved();

    void preItemReplaced();
    void postItemReplaced();

    void comboChanged(QString combo);

    void sumRowStrChanged(QString sumRowStr);

    void tsumChanged(QString tsum);

public slots:
    void getItem();
    void setCombo(QString combo);
    void setSumRowStr(QString sumRowStr);
    void setTsum(QString tsum);

private:
    QVector<VegFruitItem> mItems;
    QString m_combo;
    QString m_sumRowStr;
    QString m_tsum;
};

#endif
