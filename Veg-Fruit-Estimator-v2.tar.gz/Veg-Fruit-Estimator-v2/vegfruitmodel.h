#ifndef VEGFRUITMODEL_H
#define VEGFRUITMODEL_H

#include <QAbstractListModel>

class VegFruitList;

class VegFruitModel : public QAbstractListModel
{
    Q_OBJECT
    Q_PROPERTY(VegFruitList *list READ list WRITE setList)

public:
    explicit VegFruitModel(QObject *parent = nullptr);

    enum {
        ItemNameRole = Qt::UserRole,
        UnitRole,
        BagsRole,
        PriceRole,
        SumRole,
        CurntIndexRole
    };

    // Basic functionality:
    int rowCount(const QModelIndex &parent = QModelIndex()) const override;
    QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const override;
    // Editable:
    bool setData(const QModelIndex &index, const QVariant &value,
                 int role = Qt::EditRole) override;
    Qt::ItemFlags flags(const QModelIndex& index) const override;
    virtual QHash<int, QByteArray> roleNames() const override;

    VegFruitList *list() const;
    void setList(VegFruitList *list);

private:
    VegFruitList *mList;
};

#endif // VEGFRUITMODEL_H
