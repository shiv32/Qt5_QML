#ifndef MYTRANS_H
#define MYTRANS_H

#include <QObject>
#include <QTranslator>
#include <QGuiApplication>
#include "mylang.h"
#include <QDebug>

class mytrans  : public QObject
{
       Q_OBJECT
public:
    Q_PROPERTY(QString emptystring READ emptystring NOTIFY emptystringChanged)
    mytrans(){};

    QString emptystring()
    {
        return "";
    }

signals:
    void emptystringChanged();

public slots:
    void updatelang(int lang)
    {
        switch (lang)
        {
        case mylang::Span:
           mtrans.load(":/spanish.qm");
           qApp->installTranslator(&mtrans);   //spanish
            break;
        default:
            qApp->removeTranslator(&mtrans);  //english
            break;
        }

        emit emptystringChanged();
    }

private:
    QTranslator mtrans;
};

#endif // MYTRANS_H
