#ifndef MYLANG_H
#define MYLANG_H

#include <QObject>

class mylang :public QObject
{
    Q_OBJECT
public:
    mylang(){};

    enum E_lang
    {
        Span = 1
    };

    Q_ENUM(E_lang); //for use in qml
};

#endif // MYLANG_H
