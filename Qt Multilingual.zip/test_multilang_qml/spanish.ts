<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es" sourcelanguage="en">
<context>
    <name>main</name>
    <message>
        <location filename="main.qml" line="9"/>
        <source>Hello World</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main.qml" line="46"/>
        <source>open</source>
        <translation>abierta</translation>
    </message>
    <message>
        <location filename="main.qml" line="52"/>
        <source>close</source>
        <translation>cerca</translation>
    </message>
</context>
</TS>
