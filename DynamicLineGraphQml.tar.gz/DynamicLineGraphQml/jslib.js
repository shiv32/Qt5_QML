
//JS file

var num;

function getRandomArbitrary(min, max) {
   num = Math.random() * (max - min) + min; //generate random no. in float in range [min,max]
   return num;
}
