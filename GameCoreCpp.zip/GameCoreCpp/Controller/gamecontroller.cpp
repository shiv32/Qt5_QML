#include "gamecontroller.hpp"
#include <iostream>

GameController::GameController(QObject *parent) : QObject(parent) {
  gameLogic_ = std::make_shared<GameLogic>();
}

void GameController::increaseScore() {
  gameLogic_->increaseScore();

  setScore(gameLogic_->getScore());
}

void GameController::resetScore() {}

void GameController::setScore(int score) {
  if (m_score == score) return;

  m_score = score;
}

std::string GameController::getGameState() const {
  return gameLogic_->getGameState();
}

int GameController::score() const { return m_score; }
