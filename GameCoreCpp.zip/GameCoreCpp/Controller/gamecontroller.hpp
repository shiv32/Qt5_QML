#ifndef GAMECONTROLLER_HPP
#define GAMECONTROLLER_HPP

#include <QObject>
#include <memory>
#include "Core/GameLogic.hpp"

class GameController : public QObject {
  Q_OBJECT
  Q_PROPERTY(int score READ score WRITE setScore NOTIFY scoreChanged)
 public:
  explicit GameController(QObject *parent = nullptr);

  Q_INVOKABLE void increaseScore();
  void resetScore();
  void gameTick();  // Game loop

  int getScore() const;
  void setScore(int score);

  std::string getGameState()
      const;  // For simplicity, to show game state as string

  int score() const;

 signals:

  void scoreChanged(int score);

 private:
  std::shared_ptr<GameLogic> gameLogic_;
  int m_score{};
};

#endif  // GAMECONTROLLER_HPP
