#ifndef GAMELOGIC_H
#define GAMELOGIC_H

#include <string>

// Core C++ class without Qt-specific features for logic
class GameLogic {
public:
    GameLogic();

    void increaseScore();
    void resetScore();
    void gameTick();  // Game loop

    int getScore() const;
    void setScore(int score);
    std::string getGameState() const; // For simplicity, to show game state as string

private:
    int m_score;
};

#endif // GAMELOGIC_H
