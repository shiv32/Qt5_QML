#include "GameLogic.hpp"

GameLogic::GameLogic() : m_score(0) {}

void GameLogic::increaseScore() { m_score++; }

void GameLogic::resetScore() { m_score = 0; }

void GameLogic::gameTick() {
  // Game update logic (e.g., physics, player movement)
  increaseScore();  // Example: increase score every tick
}

int GameLogic::getScore() const { return m_score; }

void GameLogic::setScore(int score) { m_score = score; }

std::string GameLogic::getGameState() const {
  return "Game Score: " + std::to_string(m_score);  // Pure C++ string
}
