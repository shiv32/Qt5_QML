#ifndef MYSOCKET_H
#define MYSOCKET_H

#include <QObject>
#include <QTcpSocket>

class mySocket : public QObject
{
    Q_OBJECT

public:
    explicit mySocket(QObject *parent = nullptr);
    Q_PROPERTY(int num1 READ num1 WRITE setNum1 NOTIFY num1Changed)
    Q_PROPERTY(int num2 READ num2 WRITE setNum2 NOTIFY num2Changed)
    Q_PROPERTY(QString  reslt READ reslt WRITE setReslt NOTIFY resltChanged)

   Q_INVOKABLE void sendDatatoServer();

    int num1() const;
    int num2() const;
    void setNum1(int num1);
    void setNum2(int num2);
    QString reslt() const;
    void setReslt(QString reslt);

public slots:
    void onReadyRead();
    void onSocketStateChanged(QAbstractSocket::SocketState socketState);

signals:
    void num1Changed(int num1);
    void num2Changed(int num2);
    void resltChanged(QString reslt);

private:
    int m_num1;
    int m_num2;
    QString m_reslt;
    QTcpSocket  mysocket;
};

#endif // MYSOCKET_H
