#ifndef ENTERTAINMENT_H
#define ENTERTAINMENT_H

#include <QObject>

class Entertainment : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QString titles READ titles WRITE setTitles NOTIFY titlesChanged)
    Q_PROPERTY(QString imagesource READ imagesource WRITE setImagesource NOTIFY imagesourceChanged)
    Q_PROPERTY(QString myid READ myid WRITE setMyid NOTIFY myidChanged)

public:
    explicit Entertainment(QObject *parent = nullptr);
    Entertainment(const QString &titles, const QString &imagesource,const QString &myid, QObject * parent = nullptr);

    QString titles() const;
    QString imagesource() const;
    QString myid() const;
    void setTitles(QString titles);
    void setImagesource(QString imageSource);
    void setMyid(QString myid);

signals:
    void titlesChanged(QString titles);
    void imagesourceChanged(QString imageSource);
    void myidChanged(QString myid);
    void mesgChanged(QString mesg);

private:
    QString m_titles;
    QString m_imagesource;
    QString m_myid;
    QString m_mesg;
};

#endif // ENTERTAINMENT_H
