#include <QDebug>
#include "entertainment.h"

Entertainment::Entertainment(QObject *parent) : QObject(parent)
{

}

Entertainment::Entertainment(const QString &titles, const QString &imagesource,const QString &myid, QObject *parent):
    QObject(parent),m_titles(titles),m_imagesource(imagesource),m_myid(myid)
{

}

QString Entertainment::titles() const
{
    return m_titles;
}

QString Entertainment::imagesource() const
{
    return m_imagesource;
}

void Entertainment::setTitles(QString titles)
{
    if (m_titles == titles)
        return;

    m_titles = titles;
    emit titlesChanged(m_titles);
}

void Entertainment::setImagesource(QString imageSource)
{

    if (m_imagesource == imageSource)
        return;

    m_imagesource = imageSource;
    emit imagesourceChanged(m_imagesource);
}

QString Entertainment::myid() const
{
    return m_myid;
}

void Entertainment::setMyid(QString myid)
{
    if (m_myid == myid)
        return;

    m_myid = myid;
    emit myidChanged(m_myid);
}



