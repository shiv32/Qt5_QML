#ifndef DATASOURCE_H
#define DATASOURCE_H

#include <QObject>
#include "entertainment.h"
#include <QThread>

class DataSource : public QObject
{
    Q_OBJECT
public:
    explicit DataSource(QObject *parent = nullptr);

    QList<Entertainment *> dataItems();
    //=========================
    void resetModel();
    void jsonApiCall();
    void jsonApiCall2(QString);
    void addRecords( Entertainment *record);
    Q_INVOKABLE void mythread();
    Q_INVOKABLE void mythread2(QString);
    Q_INVOKABLE void clearModel();

    Q_PROPERTY(QString myposter READ myposter WRITE setMyposter NOTIFY myposterChanged);
    Q_PROPERTY(QString mytitle READ mytitle WRITE setMytitle NOTIFY mytitleChanged);
    Q_PROPERTY(QString runtime READ runtime WRITE setRuntime NOTIFY runtimeChanged);
    Q_PROPERTY(QString actors READ actors WRITE setActors NOTIFY actorsChanged);
    Q_PROPERTY(QString year READ year WRITE setYear NOTIFY yearChanged);
    Q_PROPERTY(QString rating READ rating WRITE setRating NOTIFY ratingChanged);
    Q_PROPERTY(QString mesg READ mesg WRITE setMesg NOTIFY mesgChanged)
    Q_PROPERTY(bool curlres READ curlres WRITE setCurlres NOTIFY curlresChanged);
    //==========================
    QString mytitle() const;
    QString myposter() const;
    QString runtime() const;
    QString actors() const;
    QString year() const;
    QString rating() const;
    QString mesg() const;
    bool curlres() const;

    void setMytitle(QString mytitle);
    void setMyposter(QString myposter);
    void setRuntime(QString runtime);
    void setActors(QString actors);
    void setYear(QString year);
    void setRating(QString rating);
    void setMesg(QString mesg);
    void setCurlres(bool curlres);

signals:
    void preRecordAdded();
    void postRecordAdded();
    void preMyDataClear();
    void postMyDataClear();

    void mytitleChanged(QString mytitle);
    void myposterChanged(QString myposter);
    void runtimeChanged(QString runtime);
    void actorsChanged(QString actors);
    void yearChanged(QString year);
    void ratingChanged(QString rating);
    void mesgChanged(QString mesg);
    void curlresChanged(bool curlres);

private :
    QList<Entertainment*> mRecords;
    QString m_mytitle;
    QString m_myposter;
    QString m_runtime;
    QString m_actors;
    QString m_year;
    QString m_rating;
    QString m_mesg;
    QThread *thread;
    bool m_curlres;
};
#endif // DATASOURCE_H
