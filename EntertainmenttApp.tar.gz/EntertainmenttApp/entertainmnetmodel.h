#ifndef ENTERTAINMNETMODEL_H
#define ENTERTAINMNETMODEL_H

#include <QAbstractListModel>
#include <QObject>
#include "entertainment.h"
#include "datasource.h"

class EntertainmentModel : public QAbstractListModel
{
    Q_OBJECT

    Q_PROPERTY(DataSource *  dataSource READ dataSource WRITE setDataSource NOTIFY dataSourceChanged)

    enum PersonRoles{
        TitlesRole = Qt::UserRole + 1,
        ImageSourceRole,
        MyIdRole

    };

public:
    explicit EntertainmentModel(QObject *parent = nullptr);
    int rowCount(const QModelIndex &parent = QModelIndex()) const;
    QVariant data(const QModelIndex &index, int role) const;
    bool setData(const QModelIndex &index, const QVariant &value, int role);
    Qt::ItemFlags flags(const QModelIndex& index) const;
    QHash<int, QByteArray> roleNames() const;
    void setDataSource(DataSource * dataSource);
    DataSource *dataSource() const;

signals:
    void dataSourceChanged(DataSource * dataSource);

private :
    DataSource * m_dataSource;
    bool m_signalConnected;
};

#endif // ENTERTAINMNETMODEL_H
