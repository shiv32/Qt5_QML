#include <QDebug>
#include "entertainmnetmodel.h"

EntertainmentModel::EntertainmentModel(QObject *parent) : QAbstractListModel(parent),
    m_signalConnected(false)
{
    setDataSource(new DataSource(this));
}

int EntertainmentModel::rowCount(const QModelIndex &parent) const
{
    Q_UNUSED(parent)
    return m_dataSource->dataItems().size();
}

QVariant EntertainmentModel::data(const QModelIndex &index, int role) const
{
    if (index.row() < 0 || index.row() >= m_dataSource->dataItems().size())
        return QVariant();
    //The index is valid
    Entertainment * record = m_dataSource->dataItems().at(index.row());
    if( role == TitlesRole)
        return record->titles();
    if( role == ImageSourceRole)
        return record->imagesource();
    if( role == MyIdRole)
        return record->myid();
    return QVariant();
}

bool EntertainmentModel::setData(const QModelIndex &index, const QVariant &value, int role)
{
    Entertainment * record = m_dataSource->dataItems().at(index.row());
    bool somethingChanged = false;

    switch (role) {
    case TitlesRole:
    {
        if( record->titles()!= value.toString()){
            record->setTitles(value.toString());
            somethingChanged = true;
        }
    }
        break;
    case ImageSourceRole:
    {
        if( record->imagesource()!= value.toString()){
            record->setImagesource(value.toString());
            somethingChanged = true;
        }
    }
        break;
    case MyIdRole:
    {
        if( record->myid()!= value.toString()){
            record->setMyid(value.toString());
            somethingChanged = true;
        }
    }
    }

    if( somethingChanged){
        emit dataChanged(index,index,QVector<int>() << role);
        return true;
    }
    return false;
}

Qt::ItemFlags EntertainmentModel::flags(const QModelIndex &index) const
{
    if (!index.isValid())
        return Qt::NoItemFlags;

    //return Qt::ItemIsEditable;
    return Qt::ItemIsSelectable;
}

QHash<int, QByteArray> EntertainmentModel::roleNames() const
{
    QHash<int, QByteArray> roles;
    roles[TitlesRole] = "titles";
    roles[ImageSourceRole] = "imagesource";
    roles[MyIdRole] = "myid";
    return roles;
}

DataSource *EntertainmentModel::dataSource() const
{
    return m_dataSource;
}

void EntertainmentModel::setDataSource(DataSource *dataSource)
{
    beginResetModel();

    if( m_dataSource && m_signalConnected)
        m_dataSource->disconnect(this);

    m_dataSource = dataSource;

    connect(m_dataSource,&DataSource::preRecordAdded,this,[=](){
        const int index = m_dataSource->dataItems().size();
        beginInsertRows(QModelIndex(),index,index);
    });

    connect(m_dataSource,&DataSource::postRecordAdded,this,[=](){
        endInsertRows();
    });

    connect(m_dataSource,&DataSource::preMyDataClear,this,[=](){
        beginResetModel();
    });

    connect(m_dataSource,&DataSource::postMyDataClear,this,[=](){
        endResetModel();
    });

    m_signalConnected = true;
    endResetModel();
}

