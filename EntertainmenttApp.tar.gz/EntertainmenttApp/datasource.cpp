#include "datasource.h"
#include <QFile>
#include <QDebug>
#include <QDir>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QJsonValue>
#include <QJsonParseError>

DataSource::DataSource(QObject *parent) : QObject(parent)
{
    setCurlres(false);
}

QList<Entertainment *> DataSource::dataItems()
{
    return mRecords;
}

void DataSource::addRecords(Entertainment *record)
{
    emit preRecordAdded();
    mRecords.append(record);
    emit postRecordAdded();
}

void DataSource::clearModel()
{
    emit preMyDataClear();
    mRecords.clear();
    emit postMyDataClear();
}

void DataSource::resetModel()
{
    emit preMyDataClear();
    qDebug()<<"===============> model reset called";
    emit postMyDataClear();
}

void DataSource::jsonApiCall()
{
    clearModel();
    QString FileOutPutPath = QDir::currentPath()+"/myJsonOutput.txt";
    QDir dir;
    dir.remove(FileOutPutPath);
    qDebug()<<"Current path : "<<FileOutPutPath;

    QFile file(FileOutPutPath);

    if (!file.open(QIODevice::WriteOnly | QIODevice::ReadOnly | QIODevice::Text)){
        qDebug()<<"File Open Error : "<<FileOutPutPath;
        return;
    }else
        qDebug()<<"File Open Success ";

    QString mtitle =  mytitle();
    setMytitle("");

    QString urlPath = "curl -X GET -k -H 'x-rapidapi-key: EnterYourApiKey' -H 'x-rapidapi-host: imdb-internet-movie-database-unofficial.p.rapidapi.com' -s 'https://imdb-internet-movie-database-unofficial.p.rapidapi.com/search/"+mtitle+"' >> "+FileOutPutPath;

    qDebug()<<"Url : "<<urlPath;
    int curlres = system(urlPath.toStdString().c_str());

    if(curlres !=0){
        qDebug()<<"Curl Error : "<<curlres;
        setMesg("Internate not Available");
        return;
    }else{
        qDebug()<<"Curl Success : "<<curlres;
    }

    urlPath = "cat "+FileOutPutPath;
    qDebug()<<"File Path : "<<urlPath;
    qDebug()<<"Response : ";
    system(urlPath.toStdString().c_str());
    //========== parsing =========================
    // Read JSON file
    QFile file2(FileOutPutPath);
    file2.open(QIODevice::ReadOnly);
    QByteArray rawData = file2.readAll();

    // Parse document
    QJsonDocument doc(QJsonDocument::fromJson(rawData));

    // Get JSON object
    QJsonObject json = doc.object();

    qDebug()<<"\n";
    if(!json["message"].toString().isEmpty()){
        qDebug()<<"message : "<<json["message"].toString();
        if(json["message"].toString().contains("does not exist"))
        {
            //"Endpoint\/search\/ does not exist"
            qDebug()<<"message : "<<"Endpoint search does not exist";
            setMesg("Endpoint search does not exist");
            return;
        }
    }

    QStringList actorNames;
    QJsonArray jsonArray = json["titles"].toArray();

    if(jsonArray.isEmpty())
    {
        setMesg("No Record Found");
        return;
    }

    qDebug()<<"\n";
    foreach (const QJsonValue & value, jsonArray) {
        QJsonObject obj = value.toObject();
        //actorNames.append(obj["title"].toString());

        qDebug()<<"title : "<<obj["title"].toString();
        qDebug()<<"image : "<<obj["image"].toString();
        qDebug()<<"id : "<<obj["id"].toString();

        if((!obj["image"].toString().isEmpty()) && (!obj["title"].toString().isEmpty()))
            addRecords(new Entertainment(obj["title"].toString(),obj["image"].toString(),obj["id"].toString()));
    }

    qDebug()<<"\n";
    jsonArray = json["names"].toArray();

    foreach (const QJsonValue & value, jsonArray) {
        QJsonObject obj = value.toObject();
        //actorNames.append(obj["title"].toString());

        qDebug()<<"title : "<<obj["title"].toString();
        qDebug()<<"image : "<<obj["image"].toString();
        qDebug()<<"id : "<<obj["id"].toString();
        if((!obj["image"].toString().isEmpty()) && (!obj["title"].toString().isEmpty()))
            addRecords(new Entertainment(obj["title"].toString(),obj["image"].toString(),obj["id"].toString()));
    }

    qDebug()<<"\n";
    jsonArray = json["companies"].toArray();

    foreach (const QJsonValue & value, jsonArray) {
        QJsonObject obj = value.toObject();
        //actorNames.append(obj["title"].toString());

        qDebug()<<"title : "<<obj["title"].toString();
        qDebug()<<"image : "<<obj["image"].toString();
        qDebug()<<"id : "<<obj["id"].toString();
        if((!obj["image"].toString().isEmpty()) && (!obj["title"].toString().isEmpty()))
            addRecords(new Entertainment(obj["title"].toString(),obj["image"].toString(),obj["id"].toString()));
    }
}

void DataSource::mythread()
{
    thread = QThread::create([=](){
        jsonApiCall();
    });

    connect(thread,&QThread::started,[](){
        qDebug() << "Thread started";
    });

    connect(thread,&QThread::finished,this,[=](){
        resetModel();
        qDebug() << "Thread finished";
    });

    connect(thread,&QThread::finished,thread,&QThread::deleteLater);
    thread->start();
}

void DataSource::mythread2(QString id)
{
    thread = QThread::create([=](){
        jsonApiCall2(id);
    });

    connect(thread,&QThread::started,[](){
        qDebug() << "Thread started";
    });

    connect(thread,&QThread::finished,this,[=](){
        qDebug() << "Thread finished";
    });

    connect(thread,&QThread::finished,thread,&QThread::deleteLater);
    thread->start();
}

void DataSource::jsonApiCall2(QString id)
{
    QString FileOutPutPath = QDir::currentPath()+"/myJsonOutput.txt";
    QDir dir;
    dir.remove(FileOutPutPath);
    qDebug()<<"Current path : "<<FileOutPutPath;

    QFile file(FileOutPutPath);

    if (!file.open(QIODevice::WriteOnly | QIODevice::ReadOnly | QIODevice::Text)){
        qDebug()<<"File Open Error : "<<FileOutPutPath;
        return;
    }else
        qDebug()<<"File Open Success ";

    QString urlPath = "curl -X GET -k -H 'x-rapidapi-key: EnterYourApiKey' -H 'x-rapidapi-host: imdb-internet-movie-database-unofficial.p.rapidapi.com' -s 'https://imdb-internet-movie-database-unofficial.p.rapidapi.com/film/"+id+"' >> "+FileOutPutPath;


    qDebug()<<"Url : "<<urlPath;
    int curlres = system(urlPath.toStdString().c_str());

    if(curlres !=0){
        qDebug()<<"Curl Error : "<<curlres;
        setMesg("Internate not Available");
        setCurlres(true);
        return;
    }else{
        setCurlres(true);
        qDebug()<<"Curl Success : "<<curlres;
    }

    urlPath = "cat "+FileOutPutPath;
    qDebug()<<"File Path : "<<urlPath;
    qDebug()<<"Response : ";
    system(urlPath.toStdString().c_str());

    //========== parsing =========================
    // Read JSON file
    QFile file2(FileOutPutPath);
    file2.open(QIODevice::ReadOnly);
    QByteArray rawData = file2.readAll();

    // Parse document
    QJsonDocument doc(QJsonDocument::fromJson(rawData));

    // Get JSON object
    QJsonObject json = doc.object();

    // Access properties //object parsing
    qDebug()<<"\n";
    qDebug()<<"id : "<< json["id"].toString();
    qDebug()<<"Title : "<< json["title"].toString();
    qDebug()<<"Year : "<< json["year"].toString();
    qDebug()<<"Rating : "<< json["rating"].toString();
    qDebug()<<"Poster : "<< json["poster"].toString();

    setMyposter(json["poster"].toString());
    setMytitle(json["title"].toString());
    setYear(json["year"].toString());
    setRating(json["rating"].toString());
    //================= nested object parsing ================
    QJsonObject json2 = json["trailer"].toObject();
    qDebug()<<"Trailer link : " << json2["link"].toString();
    //================== nested array object parsing============================
    QStringList actorNames;
    QJsonArray jsonArray = json["cast"].toArray();
//    foreach (const QJsonValue & value, jsonArray) {
//         QJsonObject obj = value.toObject();
//         actorNames.append(obj["actor"].toString());
//    }
    // qDebug()<<"actor : "<< actorNames;
    qDebug()<<"actor : "<<json["cast"].toArray().at(0)["actor"].toString();
    qDebug()<<"actor : "<<json["cast"].toArray().at(1)["actor"].toString();
    qDebug()<<"actor : "<<json["cast"].toArray().at(2)["actor"].toString();

    if(!json["cast"].toArray().isEmpty()){
        for(int i =0 ;i<2;i++)
            actorNames.append(json["cast"].toArray().at(i)["actor"].toString());
    }
    setActors(actorNames.join(", "));
    //================================================================================

    //=============== nested array parsing =============
    QJsonArray jsonArray2 = json["technical_specs"].toArray();
    foreach (const QJsonValue & value, jsonArray2) {
        QJsonArray obj = value.toArray();
        qDebug()<<obj[0].toString() << " : "<<obj[1].toString();

        if(obj[0].toString() == "Runtime")
        {
            setRuntime(obj[1].toString());
        }
    }
    //=====================================================
}

QString DataSource::mytitle() const
{
    return m_mytitle;
}

void DataSource::setMytitle(QString mytitle)
{
    if (m_mytitle == mytitle)
        return;

    m_mytitle = mytitle;
    emit mytitleChanged(m_mytitle);
}

QString DataSource::myposter() const
{
    return m_myposter;
}

QString DataSource::runtime() const
{
    return m_runtime;
}

QString DataSource::actors() const
{
    return m_actors;
}

void DataSource::setMyposter(QString myposter)
{
    if (m_myposter == myposter)
        return;

    m_myposter = myposter;
    emit myposterChanged(m_myposter);
}

void DataSource::setRuntime(QString runtime)
{
    if (m_runtime == runtime)
        return;

    m_runtime = runtime;
    emit runtimeChanged(m_runtime);
}

void DataSource::setActors(QString actors)
{
    if (m_actors == actors)
        return;

    m_actors = actors;
    emit actorsChanged(m_actors);
}

QString DataSource::year() const
{
    return m_year;
}

QString DataSource::rating() const
{
    return m_rating;
}

void DataSource::setYear(QString year)
{
    if (m_year == year)
        return;

    m_year = year;
    emit yearChanged(m_year);
}

void DataSource::setRating(QString rating)
{
    if (m_rating == rating)
        return;

    m_rating = rating;
    emit ratingChanged(m_rating);
}

QString DataSource::mesg() const
{
    return m_mesg;
}

void DataSource::setMesg(QString mesg)
{
    if (m_mesg == mesg)
        return;

    m_mesg = mesg;
    emit mesgChanged(m_mesg);
}

bool DataSource::curlres() const
{
    return m_curlres;
}

void DataSource::setCurlres(bool curlres)
{
    if (m_curlres == curlres)
        return;

    m_curlres = curlres;
    emit curlresChanged(m_curlres);
}
