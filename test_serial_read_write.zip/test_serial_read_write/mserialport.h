#ifndef MSERIALPORT_H
#define MSERIALPORT_H

#include <QObject>
#include <QByteArray>
#include <QSerialPort>
#include <QDebug>
#include <QCoreApplication>
#include <QTimer>

class mserialport : public QObject
{
    Q_OBJECT
public:
    explicit mserialport(QSerialPort *mserial, QObject *parent = nullptr);
    void mwritee(QByteArray &writedata);


signals:
private slots:
    void handlereadyread();
    void handlereadywrite(qint64 mbyte);
    void handletimeout();
    void handlerror(QSerialPort::SerialPortError error);

private:
    QSerialPort *m_serial = nullptr;
    QByteArray m_readdata;
    QTimer mtimer;
    //===
    QByteArray m_writedata;
    qint64 m_writtendata = 0;

};

#endif // MSERIALPORT_H
