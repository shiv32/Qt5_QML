
//========================================
//                Usage start virtual port :
//        socat -d -d pty,raw,echo=0 pty,raw,echo=0
//                        //read               //write
//        socat PTY,link=/dev/ttyS10 PTY,link=/dev/ttyS11
//
//
//========================================

#include <QCoreApplication>
#include "mserialport.h"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    int argumentcount = QCoreApplication::arguments().size();
    QStringList argumentlist = QCoreApplication::arguments();


    if(argumentcount == 1)
    {
        return 1;
    }

    QSerialPort msport;
    msport.setPortName(argumentlist.at(1));
    msport.setBaudRate(115200);


#ifdef mwrite
    msport.open(QIODevice::WriteOnly);
#else
    msport.open(QIODevice::ReadOnly);
#endif



#ifdef mwrite
    QTextStream mstdin(stdin);
    QString mline = mstdin.readLine();
    QByteArray writedata(mline.toStdString().c_str());
    mserialport mportwrite(&msport);
    mportwrite.mwritee(writedata);
#else
    mserialport mportread(&msport);

#endif

    return a.exec();
}
