#include "mserialport.h"

char buffer[50];
int numread = 0;

mserialport::mserialport(QSerialPort *mserail, QObject *parent) : QObject(parent),
    m_serial(mserail)
{
#ifdef mwrite
    connect(m_serial, &QSerialPort::bytesWritten,this,&mserialport::handlereadywrite);
    connect(m_serial, &QSerialPort::errorOccurred,this,&mserialport::handlerror);
#else
    connect(m_serial, &QSerialPort::readyRead,this,&mserialport::handlereadyread);
    connect(m_serial, &QSerialPort::errorOccurred,this,&mserialport::handlerror);
    connect(&mtimer, &QTimer::timeout,this,&mserialport::handletimeout);
    mtimer.start(5000);
#endif
}

void mserialport::mwritee(QByteArray &writedata)
{
    m_writedata = writedata;

    int writtendata = m_serial->write(writedata);

    if(writtendata == -1)
    {

        qDebug()<<"write data fail ";
        QCoreApplication::exit();
    }
}

void mserialport::handlereadyread()
{

    for(;;)
    {
        numread = m_serial->read(buffer,sizeof(buffer));

        if(numread == 0 && !m_serial->waitForReadyRead())
            break;


        qDebug()<<"read data : "<<buffer;

    }

    if(!mtimer.isActive())
    {
        mtimer.start(5000);
    }
}

void mserialport::handlereadywrite(qint64 mbyte)
{
    m_writtendata += mbyte;

    if(m_writtendata == m_writedata.size())
    {
        m_writtendata = 0;
        qDebug()<<"data write successfully";
        QCoreApplication::quit();
    }
}

void mserialport::handletimeout()
{
    QString portname = m_serial->portName();
    m_serial->close();
    m_serial->open(QSerialPort::ReadOnly);
    m_serial->setPortName(portname);
    m_serial->setBaudRate(115200);

}

void mserialport::handlerror(QSerialPort::SerialPortError error)
{
    if(error == QSerialPort::ReadError)
    {
        qDebug()<<"read error : "<<m_serial->portName()<<" : "<<m_serial->errorString();
    }

    if(error == QSerialPort::WriteError)
    {
        qDebug()<<"write error : "<<m_serial->portName()<<" : "<<m_serial->errorString();
    }

}
