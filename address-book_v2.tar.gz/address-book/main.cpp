#include <QGuiApplication>
#include <QQmlApplicationEngine>

#include "addressbookmodel.h"
#include "addressbookdata.h"
#include "sortfilterproxymodel.h"

#include <QQmlContext>
#include <QDir>

int main(int argc, char *argv[])
{
#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
#endif

    QGuiApplication app(argc, argv);

    //====
    qmlRegisterType<AddressBookmodel>("AddressBook", 1, 0, "AddressBookmodel");
    qmlRegisterUncreatableType<AddressBookData>("AddressBook", 1, 0, "AddressBookData",
        QStringLiteral("AddressBookData should not be created in QML"));
    //===
    AddressBookData addressBookData;

    QQmlApplicationEngine engine;

    //===
    engine.rootContext()->setContextProperty(QStringLiteral("addressBookData"), &addressBookData);

    //===
    qmlRegisterType<SortFilterProxyModel>("MySearch", 1, 0, "SortFilterProxyModel");

    const QUrl url(QStringLiteral("qrc:/main.qml"));
    QObject::connect(&engine, &QQmlApplicationEngine::objectCreated,
                     &app, [url](QObject *obj, const QUrl &objUrl) {
        if (!obj && url == objUrl)
            QCoreApplication::exit(-1);
    }, Qt::QueuedConnection);
    engine.load(url);

    //==========================



    //==========================

    return app.exec();
}
