#ifndef ADDRESSBOOKMODEL_H
#define ADDRESSBOOKMODEL_H

#include <QAbstractListModel>

class AddressBookData;

class AddressBookmodel : public QAbstractListModel
{
    Q_OBJECT
    Q_PROPERTY(AddressBookData *list READ list WRITE setList)
    Q_PROPERTY(int count READ count NOTIFY countChanged)

public:
    explicit AddressBookmodel(QObject *parent = nullptr);

    enum {
        IdRole= Qt::UserRole,
        NameRole,
        MobilRole,
        AddressRole
    };

    // Basic functionality:
    int rowCount(const QModelIndex &parent = QModelIndex()) const override;
    QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const override;
    bool setData(const QModelIndex &index, const QVariant &value, int role) override;
    Qt::ItemFlags flags(const QModelIndex &index) const override;
    QHash<int, QByteArray> roleNames() const override;

    AddressBookData *list() const;
    void setList(AddressBookData *list);
    int count() const;

signals:
    void countChanged(int count);

private:
    AddressBookData *mList;
    int m_count;
};

#endif // ADDRESSBOOKMODEL_H
