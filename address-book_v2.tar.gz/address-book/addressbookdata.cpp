#include "addressbookdata.h"
#include <QDebug>
#include <QDir>

//global variables
int myrow = -1;
QString p_id;
QString p_name;
QString p_mobile;
QString p_address;
QString pqml_id;
QString lastInsertRowId;
int dbflag = 0;

AddressBookData::AddressBookData(QObject *parent) : QObject(parent)
{
    //==================DB Connection ========================

    if(!dbflag){   //will run once
    const QString DRIVER("QSQLITE");

    if(QSqlDatabase::isDriverAvailable(DRIVER)){
        qDebug()<<DRIVER<<" available";
    }else
        qDebug()<<DRIVER<<" not available";

    db = QSqlDatabase::addDatabase(DRIVER);

    qDebug()<<QDir::currentPath();

    //============= create db path ===================
    QString dbDir = "mkdir "+ QDir::currentPath() +"/db/";
    QString dbPath = QDir::currentPath() +"/db/mydatabase.db";
    //qDebug()<<"dbPath  : "<<dbPath;
    QFile file(dbPath);

    if(!file.exists()){
       int sysret = system(dbDir.toStdString().c_str());
       qDebug()<<"sysret  : "<<sysret;

       if(sysret !=0)
       {
         qDebug("DB Path Create error....");
       }
         qDebug("DB Path Created....");
    }else
         qDebug("DB Path Exist !");
    //===========================================

    db.setDatabaseName( QDir::currentPath() +"/db/mydatabase.db"); //your db in projetc directory,
                                                                   //uncheck shadow build in projects
    if(!db.open())
        qWarning() << "ERROR: " << db.lastError();
    else
        qDebug()<<" db open success";

    dbflag = 1;
    }
    //===================================================================================

        //QSqlQuery query1("DROP TABLE people");
        QSqlQuery query("CREATE TABLE IF NOT EXISTS people (id INTEGER PRIMARY KEY, name TEXT, mobile TEXT, address TEXT)");

        if(!query.isActive())
            qWarning() << "ERROR: " << query.lastError().text();

        query.clear();

        query.prepare("SELECT id, name, mobile, address FROM people;");

        if(!query.exec())
            qWarning() << "ERROR: " << query.lastError().text();

        while(query.next())
        {
            p_id = query.value(0).toString();
            p_name = query.value(1).toString();
            p_mobile = query.value(2).toString();
            p_address = query.value(3).toString();

            //        qDebug()<<"p_name : "<<p_name;
            //        qDebug()<<"p_mobile : "<<p_mobile;
            //        qDebug()<<"p_address : "<<p_address;

            mItems.append({p_id,p_name,p_mobile,p_address});
        }
    //========================================================
    //mItems.append({QStringLiteral("0"),QStringLiteral("shiv kumar"),QStringLiteral("9805249425"),QStringLiteral("206 A")});
}

QVector<AddressBookitem> AddressBookData::items() const
{
    return mItems;
}

bool AddressBookData::setItemAt(int index, const AddressBookitem &item)
{
    if (index < 0 || index >= mItems.size())
        return false;

    const AddressBookitem &oldItem = mItems.at(index);
    if (item.Id == oldItem.Id && item.name == oldItem.name && item.mobile == oldItem.mobile && item.address == oldItem.address)
        return false;


    mItems[index] = item;

    qDebug()<<"mItems.size() ================================================> "<<mItems.size();

    return true;
}

void AddressBookData::getMyRow(int row) //get model row id
{
    if(row == -1)
        return;

   // qDebug()<<"c++ from book data 1 ===> "<<row;
    myrow = row;
    //qDebug()<<"c++ from book data 2===> "<<myrow;
}

void AddressBookData::getRowIdDb(int row) //get record id in DB
{
    if(row == -1)
        return;

    // qDebug()<<"c++ from book data 11 ===> "<<row;
    pqml_id = QString::number(row);
    //qDebug()<<"c++ from book data 21===> "<<pqml_id;
}

void AddressBookData::updateRow(int row)
{
    Q_UNUSED(row);

    qDebug()<<"c++ myrow ===============> "<<myrow;
    qDebug()<<"c++ pqml_id ===============> "<<pqml_id;

    //============ db update record ==================
    qDebug()<<"db Update =========================> ";

    qDebug()<<"UPDATE people SET name ='"+m_name+"',mobile ="+m_mobile+",address = '"+m_address+"' WHERE id ="+pqml_id;

    QSqlQuery query;
    if(!query.exec("UPDATE people SET name ='"+ m_name+"',mobile ="+m_mobile+",address = '"+m_address+"' WHERE id ="+pqml_id))
        qWarning() << "ERROR: " << query.lastError().text();
    //===============================================

    qDebug()<<"c++ myrow ===============> "<<myrow;
    qDebug()<<"c++ pqml_id ===============> "<<pqml_id;

    mItems.replace(myrow,{pqml_id,m_name,m_mobile,m_address});
}

QString AddressBookData::name() const
{
    return m_name;
}

QString AddressBookData::mobile() const
{
    return m_mobile;
}

QString AddressBookData::address() const
{
    return m_address;
}

void AddressBookData::appendItem(QString Id,QString name,QString mob,QString addr)
{
    Q_UNUSED(Id);
    //============get last insert row id============
    QSqlQuery query;

    query.prepare("SELECT id FROM people WHERE id = (SELECT MAX(id) FROM people);");

    if(!query.exec())
        qWarning() << "ERROR: " << query.lastError().text();

    while(query.next())
    {
        lastInsertRowId = query.value(0).toString();
        qDebug()<<"lastInsertRowId ===============================> "<<lastInsertRowId;

    }
    query.clear();
    //-------------------------------------------------
    int row_id = lastInsertRowId.toInt();
    row_id++;
    lastInsertRowId = QString::number(row_id);
    //--------------------------------------------------
    //============ db insert record ==================
    qDebug()<<"db inertion =========================> ";

    qDebug()<<"INSERT INTO people(id,name,mobile,address) VALUES('"+lastInsertRowId+"','"+name+"','"+mob+"','"+addr+"'"+")";

    if(!query.exec("INSERT INTO people(id,name,mobile,address) VALUES('"+lastInsertRowId+"','"+name+"','"+mob+"','"+addr+"'"+")"))
        qWarning() << "ERROR: " << query.lastError().text();
    //===============================================

    emit preItemAppended();

    mItems.append({lastInsertRowId,name,mob,addr});

    emit postItemAppended();
}

void AddressBookData::removeItems()
{
    if(myrow == -1){
        qDebug()<<"row -1 ==>"<<myrow;
        return;
    }

    //============ db delete record ==================
    qDebug()<<"db delete record =========================> ";

    qDebug()<<"DELETE FROM people WHERE id = "+pqml_id;

    QSqlQuery query;
    if(!query.exec("DELETE FROM people WHERE id = "+pqml_id))
        qWarning() << "ERROR: " << query.lastError().text();
    //===============================================

    emit preItemRemoved(myrow);

    mItems.removeAt(myrow);

    emit postItemRemoved();

    myrow = -1; //reset row to null
}

void AddressBookData::getItem()
{

    qDebug()<<"mItems.size() "<<mItems.size();

    //==========================get whole table data========================================
    //    for (int i = 0; i < mItems.size(); ) {

    //            mdone = mItems.at(i).done;
    //            mdes =  mItems.at(i).name;
    //            mmobile =  mItems.at(i).mobile;
    //            maddr =  mItems.at(i).address;


    //           qDebug()<<"my data : "<<mdone<<" my des: "<<mdes
    //                  <<"mobile: "<<mmobile<<"addre: "<<maddr;

    //            ++i;

    //        }
    //================================================================

    //=================== get clicked row data ============================================
    m_name =  mItems.at(myrow).name;
    m_mobile = mItems.at(myrow).mobile;
    m_address =  mItems.at(myrow).address;


    qDebug()<<"my name: "<<m_name
           <<"mobile: "<<m_mobile<<"addre: "<<m_address;
    //===========================================================
}


void AddressBookData::setName(QString name)
{
    if (m_name == name)
        return;

    m_name = name;
    emit nameChanged(m_name);
}

void AddressBookData::setMobile(QString mobile)
{
    if (m_mobile == mobile)
        return;

    m_mobile = mobile;
    emit mobileChanged(m_mobile);
}

void AddressBookData::setAddress(QString address)
{
    if (m_address == address)
        return;

    m_address = address;
    emit addressChanged(m_address);
}
