<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es" sourcelanguage="en">
<context>
    <name>main</name>
    <message>
        <location filename="main.qml" line="10"/>
        <source>Multilang QML</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main.qml" line="28"/>
        <source>Text from C++</source>
        <translation>externo de C++</translation>
    </message>
    <message>
        <location filename="main.qml" line="82"/>
        <source>open</source>
        <translation>abierta</translation>
    </message>
    <message>
        <location filename="main.qml" line="89"/>
        <source>close</source>
        <translation>cerca</translation>
    </message>
</context>
</TS>
