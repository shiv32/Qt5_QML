#ifndef MYTRANS_H
#define MYTRANS_H

#include <QObject>
#include <QTranslator>
#include <QGuiApplication>
#include "mylang.h"
#include <QDebug>
#include <iostream>

class mytrans  : public QObject
{
    Q_OBJECT
public:
    Q_PROPERTY(QString emptystring READ emptystring NOTIFY emptystringChanged)
    mytrans(){};

    QString emptystring()
    {
        return "";
    }

signals:
    void emptystringChanged();

public slots:
    void updatelang(int lang)
    {
        switch (lang)
        {
        case mylang::Span:
            mtrans.load(":/spanish.qm");
            qApp->installTranslator(&mtrans);   //spanish
            break;
        default:
            qApp->removeTranslator(&mtrans);  //english
            break;
        }

        emit emptystringChanged();
    }

    QString textFromCpp()
    {

        return "Text from C++";
    }

    Q_INVOKABLE void testTr(const QString &textFromQml)
    {
        std::cout<<"textFromQml : "<<textFromQml.toStdString()<<std::endl;

        if(textFromQml == tr("Text from C++"))
        {
            std::cout<<"tr() matched."<<std::endl;
        }
        else
        {
            std::cout<<"tr() did not match."<<std::endl;
        }
    }

    Q_INVOKABLE void testNoTr(const QString &textFromQml)
    {
        std::cout<<"textFromQml : "<<textFromQml.toStdString()<<std::endl;

        if(textFromQml == "Text from C++")
        {
            std::cout<<"string matched."<<std::endl;
        }
        else
        {
            std::cout<<"string did not match."<<std::endl;
        }
    }

private:
    QTranslator mtrans;
};

#endif // MYTRANS_H
