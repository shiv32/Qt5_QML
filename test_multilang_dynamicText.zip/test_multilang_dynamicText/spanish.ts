<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es">
<context>
    <name>main</name>
    <message>
        <location filename="main.qml" line="10"/>
        <source>Multilang QML</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main.qml" line="28"/>
        <source>Text from C++</source>
        <translation>Texto de C++</translation>
    </message>
    <message>
        <location filename="main.qml" line="81"/>
        <source>open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main.qml" line="88"/>
        <source>close</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>mytrans</name>
    <message>
        <location filename="mytrans.h" line="61"/>
        <source>Text from C++</source>
        <translation>Texto de C++</translation>
    </message>
</context>
</TS>
