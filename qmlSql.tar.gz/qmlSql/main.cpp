#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QDebug>
#include <QQmlEngine>
#include <QDir>
#include <QFile>
#include <QCryptographicHash>

int main(int argc, char *argv[])
{
#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
#endif

    QGuiApplication app(argc, argv);

    QQmlApplicationEngine engine;

    //========================== db base ========================================
     QQmlEngine qqEngine; //Creates an engine to fetch the OfflineStoragePath
     const QString dataFolder = qqEngine.offlineStoragePath();
     //Sets the Database folder
     QDir dir(dataFolder+"/Databases");

    if (!dir.exists()) {
        dir.mkpath(".");
    }

    //Encrypt the database name with MD5, default from Qt
    QString new_name = QString(QCryptographicHash::hash(("DatabaseName"),QCryptographicHash::Md5).toHex());

    //Pick the source DB to be copied to the new location with the MD5 name
    QFile file(":/DatabaseName.sqlite");
    bool ret = file.copy(dataFolder+"/Databases/" + new_name + ".sqlite");

    if(!ret)
    {
        qDebug("DB file error");
    }
    else
    {
        qDebug("DB file success");
    }

    file.close();

    //The Sqslite must have a ini file with the database version and metadata in the same folder,
    //so we also copy this file
    QFile fileIni(":/databaseName.ini");
     ret = fileIni.copy(dataFolder+"/Databases/" + new_name + ".ini");

    if(!ret)
    {
        qDebug("DB file ini error");
    }
    else
    {
        qDebug("DB file ini success");
    }

    fileIni.close();

    QString pathDetail = "ls "+dataFolder+"/Databases/";
    qDebug()<<"DB path files : "+dataFolder+"/Databases/";
    system(pathDetail.toStdString().c_str());
   //=======================================================================

    const QUrl url(QStringLiteral("qrc:/main.qml"));
    QObject::connect(&engine, &QQmlApplicationEngine::objectCreated,
                     &app, [url](QObject *obj, const QUrl &objUrl) {
        if (!obj && url == objUrl)
            QCoreApplication::exit(-1);
    }, Qt::QueuedConnection);
    engine.load(url);

    return app.exec();
}
